# Combine "Where Auto fits" and the platform heat map into one section

## The idea
One section, one headline, one OEMs / Tier 1s switch that drives everything. Reading order follows the deck: the value chain first (where to play), then the platforms (what to play in), shown as one connected view instead of two stacked blocks.

```text
Eyebrow:  Auto's multiple paths to play in Defense
Headline: Mapping Auto's opportunities across defense platforms
Subhead:  (current one-line summary)

[ OEMs | Tier 1s ]                           legend: Strong/High  Moderate  Poor/Limited

Value chain strip (7 stages left to right, each a compact tile with its fit tag)
 Design & eng. | Industrialization | Components | Systems | Final assembly | Testing | Aftermarket
    Poor            Strong            Moderate     ...
          \__________ stages Auto plays in light up and connect down __________/

Heat map (only the lit stages as rows, 8 platforms across, dots as today)
 Industrialization        o  o  o  o ...
 Component manufacturing  o  o  o  o ...
 ...

Detail panel (one at a time): click any stage tile or platform name to see its
deck description and the OEM / Tier 1 fit note. Closed by default.
```

## What changes for the reader
1. **Less text up front.** The seven long rows become one strip of seven short tiles: stage name and a fit tag. Descriptions and "Why" notes move into a single detail panel that opens when a tile is clicked, so only one piece of detail shows at a time.
2. **The two views connect.** The strip sits directly above the heat map. The stages that are rows in the heat map are highlighted in the strip, with a thin line linking them down, so it's clear the heat map zooms into those stages.
3. **One switch.** Flipping OEMs / Tier 1s updates both the strip fit tags and the heat map dots together (Tier 1s show three rows, OEMs four, as on slides 28–29).
4. **Platform descriptions** use the same detail panel (click a platform name) instead of a hover-only tooltip, which also works on phones.
5. **Kept as is:** all wording from slides 25–29, the dashed ① ground vehicles and ② drones outline, the OEM callout, the source line, and current colors.
6. **Removed:** the separate "Step 1 · Where Auto fits across the defense value chain" headline, so there is one headline for the combined section.

## Technical details
- Sections.tsx: replace the value chain block and PlatformMatrix with one `ValueChainMap` component; lift the `who` state to it; `selected` state for the detail panel (stage or platform). No copy changes in story.ts.
- Phones: strip wraps to a 2-column grid; heat map scrolls sideways as today.
- Screenshot check at laptop and phone widths, then offer a v10 PDF.
