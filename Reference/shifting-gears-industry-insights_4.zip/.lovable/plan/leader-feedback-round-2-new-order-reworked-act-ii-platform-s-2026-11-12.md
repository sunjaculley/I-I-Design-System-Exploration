# Leader feedback round 2: new order, reworked Act II, platform systems map, five keys

## 1. New opening order
```text
Hero -> Act I: What's happening now -> The opportunity at a glance -> Osnabrück -> Act II -> Act III -> KPMG
```
- **Opportunity at a glance:** the line "Defense needs production at scale. Auto has the scale, the capabilities, and the capacity to provide it" moves to sit under the band's title, above the three numbers.

## 2. "What it means" (end of Act I)
- Headline: "Defense can't build scale fast enough. Auto has scale to spare. But capacity alone won't win."
- New body copy under it: "Defense runs on different contracts, compliance requirements and supply chains. Success requires navigating both worlds."
- Sources line stays.

## 3. Act II, new running order
```text
"Most important question" banner (light blue bar removed)
-> The opportunity comes with real barriers           (replaces "So why hasn't it happened again?")
-> What's holding Auto back? Defense is a fundamentally different business.
   + new body copy
-> Issue 1: A cultural mismatch   (the five operating differences + several-governments callout)
-> Issue 2: Misaligned economic expectations  (header above 12 yrs)
-> Issue 3: Volume uncertainty                (header above -52%)
-> "The window is opening." as the intro line -> What's changing (tailwinds + mitigation)
```
- **Body copy under the new headline:** "Auto brings a lot to the table, but entering Defense is not simply a matter of applying what already works. The challenges run much deeper."
- The "Cultural mismatch, up close" label is removed. The heading is now just "A cultural mismatch". Issues 1, 2 and 3 use headings of the same size.
- The current two small boxes (economics, volume) become issues 2 and 3 under the cultural block. Their old third box (cultural mismatch) is merged into issue 1, so it isn't repeated.
- The "Defense is not Auto" table (first screenshot) is removed.
- The WWII block moves out of Act II and into Act III (see section 5).

## 4. New section before "Size of the prize": Auto's multiple paths to play in Defense
- Subheading: "Across eight high-level defense platform systems, Auto OEMs and Tier 1 suppliers have distinct opportunities to bring their capabilities to bear."
- Eight cards with the descriptions from deck page 27, word for word: Air platforms (crewed), Ground vehicles, Naval platforms, Drones (UAVs), Space & launch systems, Missiles & rockets, Precision guided munitions, Artillery & ammunition.
- Each card shows an OEM rating and a Tier 1 rating (High / Moderate / Limited potential), using the same three levels as the deck. Ratings come from the heat maps on slides 28 (OEMs) and 29 (Tier 1s).
- The deck uses coloured cells for these ratings, so I'll render both slides as images and read each cell. I won't guess. If a cell can't be read clearly, I'll tell you instead of filling it in.

## 5. WWII block moves to just before "Five keys to winning in defense"
- New headline: "We know Auto can do this. They've done it before."
- Keeps 63 min / #1 / 8 mo, Today <1%–9%, the Washington quote and sources.
- Sits after "Size of the prize" ($35–73B) and right before the five keys.

## 6. How to win
- Headline: "Five keys to winning in defense".
- Remove the "Decide the business model and compliance perimeter first" box (third screenshot). Keep items 2–6, renumbered 01–05 in this order (dedicated defense unit first), with these bodies:
  - Consider a dedicated defense unit: "Establish the business model and compliance perimeter first. Decide how defense work will sit relative to the core Auto business – integrated, firewalled, ring-fenced, or partnership/JV – before designing the operating model."
  - Organize for speed: "Defense buying is getting faster and more iterative, as new entrants field products quickly and improve them in service. Auto will need to keep pace."
  - Give primes a reason to partner: "Primes control access to most defense programs. Auto earns a place by solving a real problem, not simply offering more capacity."
  - Bring the talent, not just the capacity: "Defense production is constrained by more than factory space. Skilled labor, supplier depth, and software capability matter too, making Auto's broader production system its real advantage."
  - Seek government-supported derisking: "Reduce the risk of entry by working with government. Funding, pilots, and clearer demand signals can support investment in specialized capabilities before scaling up."

## Technical details
- `story.ts`: drop `defenseVsAuto` and the business-model success factor; update the success-factor bodies; add `platformSystems` (name, description, oem, tier1); add the new Act II and "What it means" copy.
- `Sections.tsx`: reorder so `ActNow` comes before `Glance` in `routes/index.tsx`; move the glance line; restructure `ActWhy` in the order above; add a `PlatformSystems` block in `ActWin` before the prize chart; move the WWII block into `ActWin` between the prize chart and the success factors; update the success-factor list.
- Read the ratings from pdftoppm renders of pages 28–29, then check the page at laptop width.
