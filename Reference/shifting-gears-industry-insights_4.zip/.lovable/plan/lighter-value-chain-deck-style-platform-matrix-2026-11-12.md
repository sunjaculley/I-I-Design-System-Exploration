# Lighter value chain, deck-style platform matrix

## Your questions
- **Does Step 1 match the PDF?** Yes. The stage descriptions and the OEM and Tier 1 fit notes come word for word from slides 25–26. It's dense because it shows the full fit note for every stage, twice (OEMs and Tier 1s).
- **Is the screenshot a reference?** Yes. It's slide 28 (OEMs), and slide 29 is the same view for Tier 1s. Those two slides are where the dots in Steps 2–3 come from. The site splits them into eight separate cards, which hides the grid view you see on the slide.

## Proposed changes
1. **Make Step 1 lighter.** Each stage keeps its name, its one-line description, and an OEM and a Tier 1 fit tag (Strong / Moderate / Poor). The long fit notes move behind a "Why" toggle on each row, so they're still there but closed by default. This turns seven dense rows into one easy-to-scan list.
2. **Rebuild Steps 2–3 as the slide 28/29 grid.**
   - Stages run down the side: Industrialization, Component manufacturing, Systems & subsystems production, Final / platform assembly (OEMs only).
   - The eight platform systems run across the top, with one dot per cell.
   - An OEMs / Tier 1s switch flips between slide 28 and slide 29.
   - Ground vehicles and drones are outlined with a dashed box and numbered, the way the slide does it.
   - Each platform's description shows when you hover over its name. The eight separate cards go away.
3. **Dot colors:** the deck uses green, amber and red. In KPMG colors, I suggest light blue for high, KPMG blue for moderate, and an outlined circle for limited. That matches the clearer "Poor" style. Say if you'd rather keep green, amber and red to match the slide exactly.
4. **Slide note:** add the slide's callout under the OEM grid: "For a vertically integrated play like ground vehicles, OEMs could consider expanding to adjacent value chain links (i.e., design & engineering and aftermarket) as part of entry". I'll read slide 29 for the Tier 1 version, and use its wording only if it has one.

## Technical details
- story.ts: keep valueChainFit as is; add the slide 28/29 callout text.
- Sections.tsx: Step 1 rows get a details/summary toggle for the notes; replace the platform cards with a table, using a useState switch between OEM and Tier 1 data (oemStages/tier1Stages already match the slides).
- Screenshot check at laptop and phone widths; on phones the grid scrolls sideways.
