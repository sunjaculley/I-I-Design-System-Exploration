# Act labels, cultural mismatch order, window callout

1. **Act labels back to eyebrow size.** "Act I / II / III" goes back to the small, spaced-out label style, so it no longer competes with the headlines. To make each act stand out, the label sits in a solid KPMG blue bar: a short colored band with "ACT I · WHAT'S HAPPENING NOW" in white. The bar is the full width of the text column, and there's a little space before the headline.

2. **Cultural mismatch: lead with the issue.** Yes, I'd put it first. New order:
   - "Issue 1 · A cultural mismatch" headline
   - The multiple regulatory regimes text, now shown as the lead-in under the headline (plain larger text, not a boxed callout), so it reads as the problem
   - The five operating difference boxes after it, as the specifics

3. **"The window is opening." on its own colored band.** Yes, right now it sits on the same background as the barriers and is easy to miss. It moves to a full-width solid KPMG blue band (#1E49E2) with large white text, a clear break between "what's holding Auto back" and "what's changing". The two "What's changing" boxes follow directly under it.

4. **New headline for the platform grid.** "Auto's multiple paths to play in Defense" stays as the small label above the headline, in place of "Steps 2 and 3 · Platform systems and where to play". The main headline becomes "Mapping Auto's opportunities across defense platforms". The line under it ("Across eight high-level defense platform systems…") and the grid stay as they are.

## Technical details
- primitives.tsx SectionHeader: replace large act label with `bg-secondary text-secondary-foreground` bar holding act + eyebrow in eyebrow styling.
- Sections.tsx ActWhy: move multiRegime paragraph above the operating-differences grid as intro text; wrap the window line in a full-bleed `bg-secondary` band (negative margins beyond the wrapper).
- Screenshot check at laptop width.
