# Leader feedback: opportunity-first flow, a stronger Act II, neutral entry options, operating-model point, contacts

## 1. Start with the opportunity (follow the deck's order)
The deck runs: Executive Summary, then Why Now / Why Auto, then Why It Hasn't Happened Yet & Why It Can (the WWII history opens this section), then Where to Play and How to Win. The site will follow the same order:

```text
Hero  ->  The opportunity at a glance (new)  ->  Act I: Why now, why Auto  ->  Osnabrück case
      ->  Act II: Why it hasn't happened yet (opens with WWII)  ->  Act III  ->  KPMG
```

- **Hero:** keep "Auto's next industrial opportunity" and the subhead.
- **New "The opportunity at a glance" band** right under the hero, taken from the Executive Summary: three headline numbers (~$3T global military spend, >$400B FY27 procurement request, $35–73B a year addressable for Auto) and one line saying defense needs scale and Auto has it.
- **WWII moves into Act II** as its opening, "Auto has done this before", matching the deck. Same three stats and the "<1%–9% today" contrast. It then leads into "So why hasn't it happened again?" and the barriers.
- The "Washington is asking for Detroit by name" line moves with the WWII block. The top menu order stays the same.

## 2. Act II: the most important section
- **Look:** a full-width lighter "feature" background (a cobalt-to-navy band) that sets it apart from the other acts. It gets a larger act number and a short line at the top: "The most important question: why hasn't Auto done this already?"
- **New callout: "Defense is not Auto."** A side-by-side comparison of how Auto works vs how Defense works.
- **Cultural mismatch, broken out** into a grid of operating differences. Each one gets a short "what it means for an automaker" line:
  1. Contract types and cost accounting (fixed-price vs cost-plus, CAS alongside GAAP)
  2. ITAR/EAR and controlled technical data
  3. Limits on offshore resources (engineering, IT and supply)
  4. CUI handling and CMMC cybersecurity certification
  5. Defense sustainment and supply chains (decades-long support, obsolescence, sourcing rules)
- **Callout on multiple regimes:** serving the defense needs of several governments at once (US, NATO allies, EU) adds overlapping export, data and sourcing rules.
- The other two barriers and the "What's changing" column stay, so they don't compete with the expanded cultural block.

Note: these five items aren't spelled out in the deck, so I'll write the short explanations from standard defense-contracting practice and mark them for your review.

## 3. Three ways in: neutral, conditions-based
- Remove the "Tactical step", "Strong fit" and "Higher risk" tags and the highlighted "recommended" styling. All three options get the same visual weight.
- Change the deck headline so it doesn't favour one option. The section headline "Where should Auto play in the defense ecosystem?" stays.
- Each option shows **"Makes most sense when…"** (conditions), plus pros and cons for OEMs and Tier 1s, from slide 23:
  - Contract manufacturer: when speed and low risk matter most and you have idle assembly capacity. Pros: rapid, lower-risk entry. Cons: thin margins, limited IP.
  - Tier 1 to defense players: when you have IP to protect and willing prime partners. Pros: margins, derisked entry, IP retention. Cons: becoming a supplier is a cultural shift, and it depends on a partner.
  - Full defense OEM/Prime: when you want platform ownership and can take on high investment and program risk. Pros: full value and control. Cons: competing head-to-head with the primes.

## 4. How to win: one new point
Add "Decide the business model and compliance perimeter first". You need to choose how the defense business sits relative to the core before designing the operating model. It's shown as a small spectrum: Integrated -> Firewalled -> Ring-fenced -> Partnership / JV. The headline becomes "Six keys to winning in defense".

## 5. Contacts
Replace the placeholder contacts with Lenny LaRocca, Bala Lakshman and Andrew Alesbury. Each gets a small round photo placeholder with their initials. Titles and emails stay blank until you send them.

## 6. PDF
Make v6 of the PDF once the changes are approved and on the site.

## Technical details
- `src/content/story.ts`: add `glance`, `defenseVsAuto`, `operatingDifferences`, `multiRegime`, and conditions/pros/cons on `pathways` (drop `verdict` and `recommended`); add a success factor with `spectrum`; add `contacts`.
- `Sections.tsx`: new `Glance` section; move the `Before` content inside `ActWhy`; change the `ActWhy` background and layout; rebuild the pathway cards; update the success-factor and contact rendering. Update the order in `routes/index.tsx`.
