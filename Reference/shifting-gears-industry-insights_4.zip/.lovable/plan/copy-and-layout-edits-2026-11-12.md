# Copy and layout edits

1. **Act I macrotrends headline**: remove the period, so it reads "Three macrotrends are pushing Auto to evolve".
2. **What it means**: break the headline so "But capacity alone won't win." starts on the second line (on wider screens).
3. **A cultural mismatch, five boxes**: remove the small blue arrow lines at the bottom of each box (for example "→ New pricing, estimating and accounting systems…").
4. **Five keys, card 01**: remove the boxed spectrum (Integrated → Firewalled → Ring-fenced → Partnership / JV). The card's text stays.
5. **A cultural mismatch, box titles**: replace the white titles with the "Operating difference" column from your table:
   - 1 Contract types and cost accounting
   - 2 Export controls on technical data (with "ITAR / EAR" as small text under the title)
   - 3 Use of offshore resources
   - 4 Cybersecurity requirements (with "CUI / CMMC" as small text under the title)
   - 5 Defense sustainment and supply chains
   
   Your table also has a "How defense differs" column. I'll use it to replace each box's grey text too, since the current text was my draft and yours is reviewed. Tell me if you'd rather keep the current grey text.
6. **Act III order**: put "Auto's multiple paths to play in Defense" (eight platform systems) before "Three major plays" / Size of the prize.

7. **Where Auto fits across the defense value chain**: the "Poor" boxes are hard to read. Give them a clearly visible outlined style (light blue border, white text on navy), so all three ratings stand out: Strong (solid KPMG blue), Moderate (lighter blue fill), Poor (outlined).

8. **Make the value chain section follow the deck (slides 25–29)**. The new order:
   - **Step 1, define the value chain (slides 25–26).** Seven stages, each with its one-line description from the deck (for example, Industrialization: "Getting a design ready for repeatable production: process engineering, tooling, line setup, supplier qualification and the ramp to target production rate"). Each stage shows its OEM and Tier 1 fit using the deck's wording, word for word.
   - **Step 2, define the platform systems (slide 27).** The eight platform systems with their descriptions.
   - **Step 3, where OEMs and Tier 1s can play (slides 28–29).** The existing OEM and Tier 1 ratings for each platform system.
   - This replaces the current grid that only has fit labels. It sits where the grid is now, together with the eight-systems section from item 6. "Three major plays" comes after it.

9. **Make Act I, II and III easier to spot**. Each act opens with a bold divider: a large "Act I / Act II / Act III" label in KPMG Bold and KPMG light blue, a thin full-width line, and the act's name beside the label (for example "What's happening now"). This replaces the small spaced-out label at the top of each act.
10. **One size for all headings**. All section headlines (like "Defense spending is rising, and fast" and "Five keys to winning in defense") will use the same size and line spacing. Smaller sub-headings inside sections (box titles, card titles) will also share one smaller size. The opening headline at the top of the site stays larger.

## Technical details
- Copy edits in src/content/story.ts (operatingDifferences titles, new optional `tag` field, bodies; drop `meaning` and the spectrum from successFactors).
- Sections.tsx: remove the meaning line and spectrum rendering, render the small tag, add a line break in the What it means headline, swap the two Act III blocks.
- Check with a screenshot at laptop width.
