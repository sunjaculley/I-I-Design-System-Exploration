import { createFileRoute } from "@tanstack/react-router";
import { ActNow, ActWhy, ActWin, CaseStudy, Glance, Hero, KpmgClose, TopNav } from "@/components/story/Sections";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Auto's next industrial opportunity | KPMG" },
      { name: "description", content: "How automotive companies can bring scale to defense manufacturing, and where they can play to win. A KPMG point of view." },
      { property: "og:title", content: "Auto's next industrial opportunity | KPMG" },
      { property: "og:description", content: "How automotive companies can bring scale to defense manufacturing, and where they can play to win." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <main>
      <TopNav />
      <Hero />
      <ActNow />
      <Glance />
      <CaseStudy />
      <ActWhy />
      <ActWin />
      <KpmgClose />
    </main>
  );
}
