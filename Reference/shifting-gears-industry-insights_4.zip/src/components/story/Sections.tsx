import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";
import {
  barriers, caseStudy, history, kpmgHelp, macrotrends, nav, pathways, plays, principles,
  procurement, procurementNote, tailwinds, mitigants, valueChainFit, playTakeaways, prologueToday, actNowIntro, realities, spending, successFactors, glance, whatItMeans, actWhyIntro, platformSystems, oemStages, tier1Stages, operatingDifferences, multiRegime, contacts,
} from "@/content/story";
import { CountUp, Reveal, SectionHeader, Sources, useInView } from "./primitives";

const fitClass = { strong: "bg-primary text-primary-foreground", moderate: "bg-secondary text-secondary-foreground", poor: "border border-sky text-foreground" } as const;
const wrap = "mx-auto w-full max-w-7xl px-6 md:px-10";

export function TopNav() {
  const [active, setActive] = useState("");
  const [progress, setProgress] = useState(0);
  useEffect(() => {
    const onScroll = () => {
      const h = document.documentElement;
      setProgress(h.scrollTop / Math.max(1, h.scrollHeight - h.clientHeight));
      let cur = "";
      for (const n of nav) {
        const el = document.getElementById(n.id);
        if (el && el.getBoundingClientRect().top < window.innerHeight * 0.4) cur = n.id;
      }
      setActive(cur);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-border bg-background/80 backdrop-blur">
      <div className={cn(wrap, "flex h-14 items-center justify-between")}>
        <a href="#top" className="font-display text-2xl tracking-tight">KPMG</a>
        <nav className="hidden gap-7 md:flex">
          {nav.map((n) => (
            <a key={n.id} href={`#${n.id}`} className={cn("text-xs uppercase tracking-[0.18em] transition-colors", active === n.id ? "text-primary" : "text-muted-foreground hover:text-foreground")}>
              {n.label}
            </a>
          ))}
        </nav>
      </div>
      <div className="h-0.5 bg-primary transition-[width]" style={{ width: `${progress * 100}%` }} />
    </header>
  );
}

export function Hero() {
  return (
    <section id="top" className="relative overflow-hidden bg-hero pt-14">
      <div className="absolute inset-0 grid-lines opacity-60" aria-hidden />
      <div className={cn(wrap, "relative flex min-h-[92vh] flex-col justify-center py-24")}>
        <Reveal><span className="eyebrow">A KPMG point of view · November 2026</span></Reveal>
        <Reveal delay={100}>
          <h1 className="mt-6 max-w-5xl text-5xl md:text-8xl leading-[0.92]">Auto’s next industrial opportunity</h1>
        </Reveal>
        <Reveal delay={200}>
          <p className="mt-8 max-w-2xl text-xl text-muted-foreground md:text-2xl">
            How automotive companies can bring scale to defense manufacturing, and where they can play to win
          </p>
        </Reveal>
        <Reveal delay={350}>
          <a href="#now" className="mt-12 inline-flex w-fit items-center gap-3 border-b border-primary pb-1 text-sm uppercase tracking-[0.2em] text-primary">
            Begin the story ↓
          </a>
        </Reveal>
      </div>
    </section>
  );
}

export function Glance() {
  return (
    <section id="glance" className="border-b border-border py-24">
      <div className={wrap}>
        <Reveal><span className="eyebrow">The opportunity at a glance</span></Reveal>
        <Reveal><p className="mt-6 max-w-4xl font-display text-3xl leading-[1.05] md:text-4xl">{glance.line}</p></Reveal>
        <div className="mt-12 grid gap-px overflow-hidden rounded-sm bg-border md:grid-cols-3">
          {glance.stats.map((g, i) => (
            <Reveal key={g.stat} delay={i * 120} className="bg-background p-8">
              <div className="font-display text-6xl text-primary md:text-7xl">{g.stat}</div>
              <p className="mt-4 text-muted-foreground">{g.label}</p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

export function Before() {
  return (
    <div id="before" className="mt-28 border-y border-primary/30 py-24">
      <div>
        <SectionHeader eyebrow="The precedent" title={<>We know Auto can do this. <span className="text-primary">They’ve done it before.</span></>} intro="During WWII, America's automakers became its arsenal, building products they had never made before at speeds defense had never seen." />
        <div className="mt-16 grid gap-px overflow-hidden rounded-sm bg-border md:grid-cols-3">
          {history.map((h, i) => (
            <Reveal key={h.stat} delay={i * 120} className="bg-background p-8">
              <div className="font-display text-6xl text-primary md:text-7xl">{h.stat}</div>
              <p className="mt-4 text-muted-foreground">{h.label}</p>
            </Reveal>
          ))}
        </div>
        <Reveal className="mt-20 grid items-end gap-10 md:grid-cols-[1fr_1.2fr]">
          <div>
            <span className="eyebrow">Today</span>
            <div className="mt-4 font-display text-7xl md:text-9xl">{prologueToday.stat}</div>
            <p className="mt-3 max-w-sm text-muted-foreground">{prologueToday.label}</p>
          </div>
          <blockquote className="border-l-2 border-primary pl-8 font-display text-3xl leading-[1.05] md:text-5xl">
            Now, Washington is asking<br className="hidden md:block" /> for Detroit <span className="text-primary">by name.</span>
          </blockquote>
        </Reveal>
        <Sources>{prologueToday.sources}</Sources>
      </div>
    </div>
  );
}

function ProcurementChart() {
  const { ref, inView } = useInView<HTMLDivElement>(0.4);
  const max = 413;
  return (
    <div ref={ref}>
      <div className="flex h-72 items-end gap-4">
        {procurement.map((p) => (
          <div key={p.year} className="flex flex-1 flex-col items-center gap-2">
            {p.growth && <span className="text-xs font-semibold text-primary">{p.growth}</span>}
            <span className="font-display text-xl">${p.total ?? p.base + p.mandatory}B</span>
            <div className="flex w-full flex-col justify-end overflow-hidden rounded-t-sm transition-[height] duration-[1400ms] ease-out" style={{ height: inView ? `${((p.base + p.mandatory) / max) * 190}px` : "0px" }}>
              {p.mandatory > 0 && <div className="flex items-center justify-center bg-primary text-[10px] font-semibold text-primary-foreground" style={{ flexGrow: p.mandatory }}>{p.mandatory}</div>}
              <div className="flex items-center justify-center bg-secondary text-[10px] font-semibold text-secondary-foreground" style={{ flexGrow: p.base }}>{p.base}</div>
            </div>
            <span className="flex h-8 items-start justify-center text-center text-[10px] uppercase tracking-widest text-muted-foreground">{p.year}</span>
          </div>
        ))}
      </div>
      <div className="mt-6 flex flex-wrap gap-4 text-xs text-muted-foreground">
        <span className="flex items-center gap-2"><span className="h-3 w-3 rounded-sm bg-secondary" />Base (discretionary)</span>
        <span className="flex items-center gap-2"><span className="h-3 w-3 rounded-sm bg-primary" />Mandatory / reconciliation</span>
      </div>
      <p className="mt-4 text-xs text-muted-foreground">{procurementNote}</p>
    </div>
  );
}

export function ActNow() {
  return (
    <section id="now" className="py-28">
      <div className={wrap}>
        <SectionHeader act="Act I" eyebrow="What's happening now" title={<>Defense is shifting to <span className="text-primary">mass production.</span> <br className="hidden md:block" />Traditional suppliers aren't built for it.</>} intro={actNowIntro} />
        <div className="mt-16 grid gap-6 md:grid-cols-3">
          {realities.map((r, i) => (
            <Reveal key={r.stat} delay={i * 120} className="rounded-sm border border-border bg-card p-8">
              <div className="font-display text-4xl text-primary md:text-5xl">{r.stat}</div>
              <p className="mt-4 text-muted-foreground">{r.label}</p>
            </Reveal>
          ))}
        </div>

        <div className="mt-28 grid gap-16 lg:grid-cols-[1.3fr_1fr]">
          <div>
            <Reveal><span className="eyebrow">The money is moving</span><h3 className="mt-4 text-4xl leading-[1.05] md:text-5xl">Defense spending is rising, and fast.</h3></Reveal>
            <div className="mt-10 grid grid-cols-2 gap-x-8 gap-y-12">
              {spending.map((s) => (
                <Reveal key={s.label}>
                  <div className="font-display text-5xl md:text-6xl"><CountUp value={s.value} prefix={s.prefix} suffix={s.suffix} decimals={s.decimals ?? 0} /></div>
                  <p className="mt-3 text-sm text-muted-foreground">{s.label}</p>
                </Reveal>
              ))}
            </div>
          </div>
          <Reveal className="rounded-sm border border-border bg-card p-8">
            <span className="eyebrow">Department of War procurement</span>
            <p className="mt-2 text-sm text-muted-foreground">The FY27 request more than doubles procurement.</p>
            <div className="mt-8"><ProcurementChart /></div>
          </Reveal>
        </div>

        <div className="mt-28">
          <Reveal><span className="eyebrow">Meanwhile, in Auto</span><h3 className="mt-4 max-w-3xl text-4xl leading-[1.05] md:text-5xl">Three macrotrends are pushing Auto to evolve</h3></Reveal>
          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {macrotrends.map((m, i) => (
              <Reveal key={m.n} delay={i * 120} className="flex flex-col rounded-sm border border-border bg-card p-8">
                <span className="font-display text-sm text-primary">{m.n}</span>
                <h4 className="mt-2 text-xl leading-snug">{m.title}</h4>
                <div className="mt-6 font-display text-5xl">{m.stat}</div>
                <p className="mt-2 text-sm text-muted-foreground">{m.statLabel}</p>
                <ul className="mt-6 space-y-2 text-sm text-muted-foreground">
                  {m.points.map((p) => <li key={p} className="border-t border-border pt-2">{p}</li>)}
                </ul>
                <p className="mt-auto pt-8 text-sm font-semibold text-primary">→ {m.implication}</p>
              </Reveal>
            ))}
          </div>
        </div>

        <Reveal className="mt-24 rounded-sm bg-secondary p-10 text-secondary-foreground md:p-16">
          <span className="text-xs font-semibold uppercase tracking-[0.22em] opacity-80">What it means</span>
          <p className="mt-5 max-w-5xl font-display text-3xl leading-[1.05] md:text-5xl">{whatItMeans.headline.split("|").map((l, i) => <span key={i}>{i > 0 && <br className="hidden md:block" />}{i > 0 && " "}{l}</span>)}</p>
          <p className="mt-6 max-w-3xl text-lg opacity-90 md:text-xl">{whatItMeans.body}</p>
        </Reveal>
        <Sources>SIPRI; NATO; Department of War (DoW) Comptroller FY24–FY27 budget documents; Reuters; Defense Daily; KPMG Research & Analysis.</Sources>
      </div>
    </section>
  );
}

export function CaseStudy() {
  return (
    <section id="case" className="bg-paper py-28 text-ink">
      <div className={wrap}>
        <Reveal>
          <span className="text-xs font-semibold uppercase tracking-[0.22em] text-cobalt">Case study</span>
          <h2 className="mt-5 max-w-4xl text-4xl leading-[1.05] md:text-5xl">{caseStudy.title}</h2>
        </Reveal>
        <div className="mt-14 grid gap-14 lg:grid-cols-[1.2fr_1fr]">
          <div className="space-y-6">
            {caseStudy.context.map((c, i) => (
              <Reveal key={i} delay={i * 100} className="flex gap-6 border-t border-ink/15 pt-6">
                <span className="font-display text-cobalt">0{i + 1}</span>
                <p className="text-lg">{c}</p>
              </Reveal>
            ))}
          </div>
          <div className="grid gap-px overflow-hidden rounded-sm bg-ink/15">
            {caseStudy.impact.map((m) => (
              <Reveal key={m.stat} className="bg-paper p-8">
                <div className="font-display text-6xl text-kpmg">{m.stat}</div>
                <p className="mt-2 text-ink/70">{m.label}</p>
              </Reveal>
            ))}
          </div>
        </div>
        <p className="mt-14 text-xs text-ink/50">Impact figures are early or anticipated. Sources: public announcements; KPMG analysis.</p>
      </div>
    </section>
  );
}

export function ActWhy() {
  return (
    <section id="why" className="relative overflow-x-clip border-y-4 border-primary bg-gradient-to-b from-cobalt/40 via-secondary/20 to-background py-28">
      <div className={wrap}>
        <SectionHeader act="Act II" eyebrow="The opportunity comes with real barriers" title={<>What’s holding Auto back? <span className="text-primary">Defense is a fundamentally different business.</span></>} intro={actWhyIntro} />
        <div className="mt-20">
          <Reveal><span className="eyebrow">Issue 1</span><h3 className="mt-3 text-4xl leading-[1.05] md:text-5xl">A cultural mismatch</h3><p className="mt-6 max-w-3xl text-lg text-muted-foreground md:text-xl">{multiRegime}</p></Reveal>
          <div className="mt-10 grid gap-4 md:grid-cols-2 lg:grid-cols-5">
            {operatingDifferences.map((d, i) => (
              <Reveal key={d.title} delay={i * 80} className="flex flex-col rounded-sm border border-border bg-card/70 p-6">
                <span className="font-display text-3xl text-primary">{i + 1}</span>
                <h4 className="mt-3 text-xl leading-snug">{d.title}</h4>
                {d.tag && <span className="mt-1 text-xs font-semibold tracking-wider text-primary">{d.tag}</span>}
                <p className="mt-3 text-sm text-muted-foreground">{d.body}</p>
              </Reveal>
            ))}
          </div>
        </div>
        <div className="mt-20 grid gap-10 md:grid-cols-2">
          {barriers.slice(0, 2).map((b, n) => (
            <div key={b.title}>
              <Reveal><span className="eyebrow">Issue {n + 2}</span><h3 className="mt-3 text-4xl leading-[1.05] md:text-5xl">{b.title}</h3></Reveal>
              <Reveal className="mt-8 rounded-sm border border-border bg-card/60 p-6">
                <span className="font-display text-6xl leading-none text-foreground">{b.stat}</span>
                <p className="mt-2 text-xs text-muted-foreground">{b.statLabel}</p>
                <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
                  {b.points.map((pt) => { const i = pt.indexOf(": "); return <li key={pt} className="border-t border-border pt-2">{i > 0 ? <><div className="font-semibold text-foreground">{pt.slice(0, i)}</div><p className="mt-0.5 text-xs leading-relaxed">{pt.slice(i + 2)}</p></> : pt}</li>; })}
                </ul>
              </Reveal>
            </div>
          ))}
        </div>
        <Reveal className="relative left-1/2 mt-28 w-screen -translate-x-1/2 bg-secondary py-16 text-center text-secondary-foreground md:py-20">
          <p className="font-display text-5xl md:text-7xl">The window is opening.</p>
        </Reveal>
        <div className="mt-12">
          <span className="text-xs uppercase tracking-[0.2em] text-primary">What's changing</span>
          <div className="mt-6 grid gap-6 md:grid-cols-2">
            {[{ h: "Market and fit tailwinds", sub: "Why the opportunity is attractive now", items: tailwinds }, { h: "Active barrier mitigation", sub: "How risks are being addressed", items: mitigants }].map((g) => (
              <Reveal key={g.h} className="rounded-sm border border-primary bg-primary/10 p-6 shadow-[0_0_40px_-12px_var(--primary)]">
                <h3 className="text-xl text-primary">{g.h}</h3>
                <p className="mt-1 text-xs text-muted-foreground">{g.sub}</p>
                <ul className="mt-4 space-y-3">
                  {g.items.map((it) => (
                    <li key={it.title} className="border-t border-border pt-3">
                      <div className="flex gap-2 font-semibold"><span className="text-primary">✓</span>{it.title}</div>
                      <p className="mt-1 pl-5 text-xs leading-relaxed text-muted-foreground">{it.body}</p>
                    </li>
                  ))}
                </ul>
              </Reveal>
            ))}
          </div>
        </div>
        <div className="mb-12" />
        <Sources>Government Accountability Office; U.S. Army; Defense News; U.S. Senate Appropriations Committee; Congressional Research Service; DoW FY2027 Mandatory Funding Overview and Acquisition Transformation Strategy; NATO; expert interviews; KPMG analysis.</Sources>
      </div>
    </section>
  );
}

const dotClass = { h: "bg-primary", m: "bg-secondary", l: "border-2 border-sky/70" } as const;
const potLabel = { h: "High", m: "Moderate", l: "Limited" } as const;
const plays12 = ["Ground vehicles", "Drones (UAVs)"];

type Sel = { kind: "stage"; i: number } | { kind: "platform"; i: number } | null;

function ValueChainMap() {
  const [who, setWho] = useState<"oem" | "tier1">("oem");
  const [sel, setSel] = useState<Sel>(null);
  const stages = who === "oem" ? oemStages : tier1Stages;
  const toggle = (s: Exclude<Sel, null>) => setSel((c) => (c && c.kind === s.kind && c.i === s.i ? null : s));
  const vs = sel?.kind === "stage" ? valueChainFit[sel.i] : null;
  const ps = sel?.kind === "platform" ? platformSystems[sel.i] : null;
  return (
    <Reveal className="mt-10 rounded-sm border border-border bg-card p-6 md:p-8">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="inline-flex rounded-sm border border-border p-1">
          {(["oem", "tier1"] as const).map((k) => <button key={k} onClick={() => setWho(k)} className={cn("rounded-sm px-4 py-2 text-xs font-semibold uppercase tracking-wider", who === k ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground")}>{k === "oem" ? "OEMs" : <>Tier 1<span className="normal-case">s</span></>}</button>)}
        </div>
        <div className="flex flex-wrap gap-4 text-xs text-muted-foreground">
          {(["strong", "moderate", "poor"] as const).map((f) => <span key={f} className={cn("rounded-sm px-2 py-0.5 font-semibold capitalize", fitClass[f])}>{f}</span>)}
          <span className="opacity-60">|</span>
          {(["h", "m", "l"] as const).map((k) => <span key={k} className="flex items-center gap-2"><span className={cn("h-3 w-3 rounded-full", dotClass[k])} />{potLabel[k]}</span>)}
        </div>
      </div>

      <p className="mt-8 text-xs font-semibold uppercase tracking-[0.2em] text-primary">Step 1 · The defense value chain</p>
      <div className="mt-3 grid grid-cols-2 gap-2 md:grid-cols-4 lg:grid-cols-7">
        {valueChainFit.map((v, i) => {
          const f = who === "oem" ? v.oem : v.tier1;
          const lit = stages.includes(v.stage);
          const on = sel?.kind === "stage" && sel.i === i;
          return (
            <button key={v.stage} onClick={() => toggle({ kind: "stage", i })} className={cn("relative flex flex-col items-start gap-3 rounded-sm border p-3 text-left transition-colors", lit ? "border-primary bg-primary/10" : "border-border opacity-70 hover:opacity-100", on && "ring-2 ring-primary")}>
              <span className="text-[10px] font-semibold text-muted-foreground">0{i + 1}</span>
              <span className="font-display text-sm leading-tight">{v.stage}</span>
              <span className={cn("mt-auto rounded-sm px-2 py-0.5 text-[11px] font-semibold capitalize", fitClass[f])}>{f}</span>
              {lit && <span aria-hidden className="absolute -bottom-3 left-1/2 hidden h-3 w-px bg-primary lg:block" />}
            </button>
          );
        })}
      </div>

      <p className="mt-10 text-xs font-semibold uppercase tracking-[0.2em] text-primary">Step 2 · Where to play across platforms, in the highlighted stages</p>
      <div className="mt-3 overflow-x-auto border-t-2 border-primary">
        <table className="w-full min-w-[820px] border-collapse text-sm">
          <thead><tr><th className="w-44" />{platformSystems.map((p, i) => { const n = plays12.indexOf(p.name); const on = sel?.kind === "platform" && sel.i === i; return (
            <th key={p.name} className={cn("px-2 pb-3 pt-2 text-left align-bottom", n >= 0 && "border-x-2 border-t-2 border-dashed border-sky/70 bg-primary/5")}>
              <button onClick={() => toggle({ kind: "platform", i })} className={cn("text-left text-xs font-semibold underline decoration-dotted underline-offset-4 hover:text-primary", on ? "text-primary" : "text-foreground")}>
                {n >= 0 && <span className="mb-1 flex h-5 w-5 items-center justify-center rounded-full border border-sky text-[10px] text-primary no-underline">{n + 1}</span>}{p.name}</button></th>); })}</tr></thead>
          <tbody>{stages.map((st, j) => (
            <tr key={st} className="border-t border-border">
              <th className="py-4 pr-4 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground">{st}</th>
              {platformSystems.map((p) => { const v = (who === "oem" ? p.oem : p.tier1)[j] ?? "l"; const n = plays12.indexOf(p.name); return (
                <td key={p.name} className={cn("py-4 text-center", n >= 0 && "border-x-2 border-dashed border-sky/70 bg-primary/5", n >= 0 && j === stages.length - 1 && "border-b-2")}>
                  <span title={`${p.name} · ${st}: ${potLabel[v]} potential`} className={cn("inline-block h-5 w-5 rounded-full", dotClass[v])} /><span className="sr-only">{potLabel[v]}</span>
                </td>); })}
            </tr>))}</tbody>
        </table>
      </div>

      {(vs || ps) && (
        <div className="mt-6 rounded-sm border-l-2 border-primary bg-primary/10 p-5">
          <div className="flex items-start justify-between gap-4">
            <h4 className="text-xl leading-snug">{vs?.stage ?? ps?.name}</h4>
            <button onClick={() => setSel(null)} aria-label="Close details" className="text-muted-foreground hover:text-foreground">✕</button>
          </div>
          <p className="mt-2 text-sm text-muted-foreground">{vs?.description ?? ps?.description}</p>
          {vs && <div className="mt-4 grid gap-4 md:grid-cols-2">
            {([["OEMs", vs.oem, vs.oemNote], ["Tier 1s", vs.tier1, vs.tier1Note]] as const).map(([label, f, note]) => (
              <div key={label}><div className="flex items-center gap-3"><span className="text-xs font-semibold uppercase tracking-wider">{label === "OEMs" ? "OEMs" : <>Tier 1<span className="normal-case">s</span></>}</span><span className={cn("rounded-sm px-2 py-0.5 text-xs font-semibold capitalize", fitClass[f])}>{f}</span></div><p className="mt-2 text-sm">{note}</p></div>
            ))}
          </div>}
        </div>
      )}

      <p className="mt-4 text-xs text-muted-foreground">Click a stage or platform name for details. ① Ground vehicles and ② drones are the major plays.</p>
      {who === "oem" && <p className="mt-4 max-w-3xl border-l-2 border-primary pl-4 text-sm">For a vertically integrated play like ground vehicles, OEMs could consider expanding to adjacent value chain links (i.e., design &amp; engineering and aftermarket) as part of entry</p>}
      <p className="mt-4 text-xs text-muted-foreground">Source: Subject matter expert interviews (both auto industry and aerospace &amp; defense); KPMG analysis</p>
    </Reveal>
  );
}

export function ActWin() {
  return (
    <section id="win" className="border-t border-border bg-hero py-28">
      <div className={wrap}>
        <SectionHeader act="Act III" eyebrow="Where to play and how to win" title={<>Five things to look for in a defense opportunity</>} />
        <div className="mt-14 grid gap-4 md:grid-cols-5">
          {principles.map((p, i) => (
            <Reveal key={p.title} delay={i * 80} className="rounded-sm border border-border bg-card/70 p-6">
              <span className="font-display text-4xl text-primary">{i + 1}</span>
              <h3 className="mt-4 text-xl leading-snug">{p.title}</h3>
              <p className="mt-3 text-sm text-muted-foreground">{p.body}</p>
            </Reveal>
          ))}
        </div>

        <div className="mt-28">
          <Reveal><span className="eyebrow">Three ways in</span><h3 className="mt-4 text-4xl leading-[1.05] md:text-5xl">Where should Auto play in the defense ecosystem?</h3></Reveal>
          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {pathways.map((p) => (
              <Reveal key={p.n} className="flex flex-col rounded-sm border border-border bg-card/70 p-8">
                <span className="text-xs uppercase tracking-[0.2em] opacity-75">Option {p.n}</span>
                <h4 className="mt-3 text-xl leading-snug">{p.title}</h4>
                <p className="mt-4 text-muted-foreground">{p.body}</p>
                <div className="mt-6 rounded-sm bg-primary/10 p-4"><span className="text-xs font-semibold uppercase tracking-wider text-primary">Makes most sense when</span><p className="mt-1 text-sm">{p.when}</p></div>
                <dl className="mt-6 grid gap-4 border-t border-border pt-4 text-sm">
                  <div><dt className="text-xs font-semibold uppercase tracking-wider opacity-75">Pros</dt>{p.pros.map((x) => <dd key={x} className="mt-1 text-muted-foreground">+ {x}</dd>)}</div>
                  <div><dt className="text-xs font-semibold uppercase tracking-wider opacity-75">Cons</dt>{p.cons.map((x) => <dd key={x} className="mt-1 text-muted-foreground">− {x}</dd>)}</div>
                </dl>
              </Reveal>
            ))}
          </div>
        </div>

        <div className="mt-28">
          <Reveal>
            <span className="eyebrow">Auto’s multiple paths to play in Defense</span>
            <h3 className="mt-4 text-4xl leading-[1.05] md:text-5xl">Mapping Auto’s opportunities across defense platforms</h3>
            <p className="mt-5 max-w-3xl text-lg text-muted-foreground">Across eight high-level defense platform systems, Auto OEMs and Tier 1 suppliers have distinct opportunities to bring their capabilities to bear.</p>
          </Reveal>
          <ValueChainMap />
        </div>

        <Reveal className="mt-28">
          <span className="eyebrow">Three major plays · The size of the prize</span>
          <h3 className="mt-4 text-4xl leading-[1.05] md:text-5xl">Industrializing systems and subsystems plays to Auto’s strengths</h3>
          <p className="mt-5 mb-10 max-w-3xl text-lg text-muted-foreground">Not every defense opportunity is a fit. The strongest build on existing capabilities and scale.</p>
          <div className="mt-4 grid items-end gap-8 md:grid-cols-[auto_1fr]">
            <div className="font-display text-7xl text-primary md:text-9xl">$35–73B</div>
            <p className="max-w-md text-lg text-muted-foreground">Estimated annual addressable opportunity for Auto across three plays, within a broader <span className="text-foreground">~$125B</span> FY27 value pool.</p>
          </div>
          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {plays.map((p) => (
              <div key={p.id} className="flex flex-col rounded-sm border border-border bg-card p-8">
                <h4 className="text-xl leading-snug">{p.title}</h4>
                <span className="mt-2 inline-block self-start rounded-sm bg-muted px-2 py-1 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Fit: {p.fit.replace("Tier 1s", "")}{p.fit.includes("Tier 1s") && <>Tier 1<span className="normal-case">s</span></>}</span>
                <div className="mt-6 flex h-40 items-end gap-4">
                  <div className="flex flex-1 flex-col items-center gap-2"><span className="font-display text-xl text-foreground">${p.pool}B</span><div className="w-full rounded-t-sm bg-accent" style={{ height: `${(p.pool / 54) * 120}px` }} /><span className="text-[10px] uppercase tracking-widest text-muted-foreground">Value at stake</span></div>
                  <div className="flex flex-1 flex-col items-center gap-2"><span className="font-display text-xl text-primary">{p.range}</span><div className="w-full rounded-t-sm bg-primary" style={{ height: `${(p.high / 54) * 120}px` }} /><span className="text-[10px] uppercase tracking-widest text-muted-foreground">Addressable</span></div>
                </div>
                <p className="mt-6 text-sm text-muted-foreground">{p.body}</p>
              </div>
            ))}
          </div>
          <ul className="mt-8 space-y-2 text-sm text-muted-foreground">
            {playTakeaways.map((t) => <li key={t} className="border-t border-border pt-2">{t}</li>)}
          </ul>
        </Reveal>

        <Before />

        <div className="mt-28">
          <Reveal><span className="eyebrow">How to win</span><h3 className="mt-4 text-4xl leading-[1.05] md:text-5xl">Five keys to winning in defense</h3></Reveal>
          <div className="mt-12 divide-y divide-border border-y border-border">
            {successFactors.map((s, i) => (
              <Reveal key={s.title} className="grid gap-2 py-6 md:grid-cols-[80px_1fr_1.4fr] md:items-baseline">
                <span className="font-display text-primary">0{i + 1}</span>
                <h4 className="text-xl leading-snug">{s.title}</h4>
                <p className="text-muted-foreground">{s.body}</p>
              </Reveal>
            ))}
          </div>
        </div>
        <Sources>FY27 DoW Budget Request; expert interviews (auto and A&D); KPMG analysis.</Sources>
      </div>
    </section>
  );
}

export function KpmgClose() {
  return (
    <section id="kpmg" className="bg-paper py-28 text-ink">
      <div className={wrap}>
        <Reveal>
          <span className="text-xs font-semibold uppercase tracking-[0.22em] text-cobalt">How KPMG can help</span>
          <h2 className="mt-5 max-w-4xl text-4xl leading-[1.05] md:text-5xl">Deep Auto and A&amp;D expertise</h2>
          <p className="mt-6 max-w-2xl text-lg text-ink/70">KPMG brings extensive work across automotive strategy, manufacturing, and transactions together with longstanding capabilities in the defense industry and government contracting, supported by 25+ dedicated A&amp;D specialists.</p>
        </Reveal>
        <Reveal className="mt-16">
          <h3 className="text-2xl md:text-4xl">Here’s how we can help</h3>
        </Reveal>
        <div className="mt-8 grid gap-8 md:grid-cols-2 lg:grid-cols-5 lg:gap-6">
          {kpmgHelp.map((k, i) => (
            <Reveal key={k.step} delay={i * 80} className="flex flex-col border-t-4 border-kpmg pt-6">
              <span className="font-display text-cobalt">Stage {i + 1}</span>
              <h4 className="mt-2 font-display text-2xl leading-tight">{k.step}</h4>
              <p className="mt-3 text-sm font-semibold text-ink/80">{k.question}</p>
              <p className="mt-3 mb-4 text-sm text-ink/70">{k.body}</p>
              <p className="mt-auto border-t border-ink/15 pt-3 text-xs text-ink/60"><span className="font-semibold uppercase tracking-wider text-cobalt">Proof points · </span>{k.proof}</p>
            </Reveal>
          ))}
        </div>
        <Reveal className="mt-24 flex flex-col items-start justify-between gap-8 rounded-sm bg-kpmg p-10 text-paper md:flex-row md:items-center md:p-14">
          <div>
            <h3 className="text-4xl leading-[1.05] md:text-5xl">Start the conversation.</h3>
            <div className="mt-6 flex flex-wrap gap-8">{contacts.map((c) => <div key={c.name} className="flex items-center gap-3"><img src={c.photo} alt={`Photo of ${c.name}`} className="h-14 w-14 rounded-full border border-paper/40 object-cover object-top" /><span className="font-semibold">{c.name}</span></div>)}</div>
          </div>
        </Reveal>
      </div>
      <footer className={cn(wrap, "mt-20 text-xs text-ink/50")}>
        © 2026 KPMG LLP, a Delaware limited liability partnership, and its subsidiaries are part of the KPMG global organization of independent member firms affiliated with KPMG International Limited. All rights reserved.
      </footer>
    </section>
  );
}
