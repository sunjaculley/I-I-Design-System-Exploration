import { useEffect, useRef, useState, type ReactNode } from "react";
import { cn } from "@/lib/utils";

export function useInView<T extends Element>(threshold = 0.2) {
  const ref = useRef<T>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([e]) => {
        if (e?.isIntersecting) {
          setInView(true);
          io.disconnect();
        }
      },
      { threshold },
    );
    io.observe(el);
    return () => io.disconnect();
  }, [threshold]);
  return { ref, inView };
}

export function Reveal({ children, className, delay = 0 }: { children: ReactNode; className?: string; delay?: number }) {
  const { ref, inView } = useInView<HTMLDivElement>(0.15);
  return (
    <div ref={ref} className={cn("reveal", inView && "is-visible", className)} style={{ transitionDelay: `${delay}ms` }}>
      {children}
    </div>
  );
}

export function CountUp({ value, prefix = "", suffix = "", decimals = 0 }: { value: number; prefix?: string; suffix?: string; decimals?: number }) {
  const { ref, inView } = useInView<HTMLSpanElement>(0.4);
  const [n, setN] = useState(0);
  useEffect(() => {
    if (!inView) return;
    const start = performance.now();
    let raf = 0;
    const tick = (t: number) => {
      const p = Math.min(1, (t - start) / 1400);
      setN(value * (1 - Math.pow(1 - p, 3)));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [inView, value]);
  return (
    <span ref={ref}>
      {prefix}
      {n.toFixed(decimals)}
      {suffix}
    </span>
  );
}

export function SectionHeader({ act, eyebrow, title, intro }: { act?: string; eyebrow: string; title: ReactNode; intro?: ReactNode }) {
  return (
    <Reveal className="max-w-5xl">
      {act ? (
        <div className="mb-8 flex items-center gap-3 rounded-sm bg-secondary px-5 py-3 text-xs font-semibold uppercase tracking-[0.22em] text-secondary-foreground">
          <span>{act}</span><span aria-hidden className="opacity-60">·</span><span>{eyebrow}</span>
        </div>
      ) : <span className="eyebrow">{eyebrow}</span>}
      <h2 className="mt-5 text-4xl leading-[1.05] md:text-5xl">{title}</h2>
      {intro && <p className="mt-6 max-w-2xl text-lg text-muted-foreground">{intro}</p>}
    </Reveal>
  );
}

export function Sources({ children }: { children: ReactNode }) {
  return <p className="mt-14 text-xs text-muted-foreground/70">Sources: {children}</p>;
}
