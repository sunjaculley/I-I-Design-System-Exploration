import { createFileRoute } from "@tanstack/react-router";
import { ActNow, ActWhy, ActWin, Before, CaseStudy, Hero, KpmgClose, TopNav } from "@/components/story/Sections";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "The Automotive Opportunity | KPMG" },
      { name: "description", content: "How Auto's capabilities can strengthen the defense industrial base, and where automakers can play to win. A KPMG point of view." },
      { property: "og:title", content: "The Automotive Opportunity | KPMG" },
      { property: "og:description", content: "Why defense needs Auto's scale now, what has held Auto back, and where to play and win." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <main>
      <TopNav />
      <Hero />
      <Before />
      <ActNow />
      <CaseStudy />
      <ActWhy />
      <ActWin />
      <KpmgClose />
    </main>
  );
}
