// All microsite copy lives here so it can be edited in one place.
// Figures sourced from "The Automotive Opportunity" (KPMG, Nov 2026).

export const nav = [
  { id: "now", label: "Now" },
  { id: "case", label: "Case study" },
  { id: "why", label: "Why not / Why now" },
  { id: "win", label: "Where to win" },
  { id: "kpmg", label: "KPMG" },
];

export const history = [
  { stat: "63 min", label: "Ford's Willow Run plant rolled out one B-24 bomber every 63 minutes using car assembly-line methods." },
  { stat: "#1", label: "By the end of WWII, GM was the largest US defense contractor, at ~$12B of war materiel." },
  { stat: "8 mo", label: "Chrysler built the Army's first dedicated tank plant and was turning out tanks within 8 months." },
];

export const prologueToday = {
  stat: "<1%–9%",
  label: "Defense share of revenue among select Auto players with disclosed figures. Current participation remains limited, with activity largely concentrated in companies' core automotive capabilities.",
  sources: "Automotive News; The Henry Ford; U.S. Army; Archives of Michigan; U.S. Auto Industry in World War Two",
};

export const actNowIntro = "Modern conflict rewards large-volume, cost-efficient production. The traditional defense industrial base runs on low-rate, high-complexity production, specialized suppliers, lengthy qualification cycles, and program-by-program execution.";

export const realities = [
  { stat: "60–70%", label: "of casualties in Ukraine come from high-volume, first-person-view drones" },
  { stat: "$4M vs $20K", label: "A Patriot missile intercepting a Shahed-style drone: the cost curve has flipped" },
  { stat: "2–3×", label: "faster to production for disruptors than for traditional defense manufacturers" },
];

export const spending = [
  { value: 3, prefix: "~$", suffix: "T", label: "Estimated world military spending in 2025, the 11th straight annual increase" },
  { value: 14.6, prefix: "~", suffix: "%", decimals: 1, label: "Average annual spending growth for NATO Europe & Canada over the past 3 years" },
  { value: 5, prefix: "~", suffix: "%", label: "of GDP: NATO's new defense spending commitment" },
  { value: 400, prefix: ">$", suffix: "B", label: "DoW FY27 procurement request, more than $200B above FY26, incl. ~$156B mandatory funding" },
];

// DoW procurement budget requests ($B), slide 11
export const procurement: { year: string; base: number; mandatory: number; growth?: string }[] = [
  { year: "FY24", base: 170, mandatory: 0 },
  { year: "FY25", base: 168, mandatory: 0 },
  { year: "FY26", base: 153, mandatory: 52, growth: "+23%" },
  { year: "FY27 (requested)", base: 258, mandatory: 156, growth: "+101%" },
];

export const procurementNote = "Mandatory (reconciliation) funding comes from a fast-track budget law outside annual appropriations, first passed in 2025 (P.L. 119-21). Excludes emergency supplementals (~$29B in FY24 and $6B in FY25). FY27 segments as shown on the budget request; total $413B.";

export const macrotrends = [
  {
    n: "01",
    title: "Competition from China",
    stat: "−6.6 pts",
    statLabel: "global share lost by the Detroit Three in 5 years",
    points: ["~5.6M units of capacity", "~35% cost advantage for a Chinese EV", "China is now the world's largest auto exporter"],
    implication: "Need for revenue diversification",
  },
  {
    n: "02",
    title: "Tech-integrated products",
    stat: "~50%",
    statLabel: "of vehicle cost will be electronics by 2030",
    points: ["Half of 2025 cars sold had L2 automation", "Auto software expected to grow >4× faster than the auto market through 2035"],
    implication: "Capabilities that overlap with defense systems",
  },
  {
    n: "03",
    title: "Stranded capacity",
    stat: ">5M",
    statLabel: "vehicles of excess annual capacity in Europe",
    points: ["European plant utilization ~60%", "US utilization ~66% (Q2 2026)", "~100k European auto job cuts in 2024–25"],
    implication: "Capacity that could be repurposed for defense",
  },
];

export const caseStudy = {
  title: "Osnabrück: From car plant to defense production",
  context: [
    "VW carried >500k vehicles of surplus European capacity and planned to end Osnabrück production by summer 2027.",
    "In Sept. 2026, VW agreed to sell the site to Aurelius Capital (majority) and the State of Lower Saxony (minority, and VW's #2 shareholder).",
    "Rafael, maker of Iron Dome, plans to join as an industrial partner. The Osnabrück workforce will industrialize air defense components, with VW expected to contribute ramp-up expertise. (No missiles built on site.)",
  ],
  impact: [
    { stat: "75%", label: "of VW jobs expected to be retained" },
    { stat: "1st", label: "VW plant to be repurposed rather than closed" },
    { stat: "~45K", label: "at-risk employees at 4 other VW plants for whom this model could be considered" },
  ],
};

export const barriers = [
  { title: "Misaligned economic expectations", stat: "12 yrs", points: ["Long timelines: major defense programs take 12 years on average to deliver first capability, so capital takes far longer to pay back", "ROI & volume thresholds: defense volumes can be too small and uncertain to clear auto return hurdles"] },
  { title: "Volume uncertainty", stat: "−52%", points: ["Demand declines sharply after conflicts (DoD procurement fell 52% in 1987–95)", "Unpredictable budget timing: 37 of the last 49 fiscal years started without a full-year budget", "Programs can be cancelled midstream, stranding suppliers' investments"] },
  { title: "Cultural mismatch", stat: "2 sets", points: ["Government-specific buying: complex processes, government-only terms and long contracting timelines", "IP ownership: DoW often seeks rights to contractors' technical data", "Separate accounting: a second set of books under CAS alongside GAAP"] },
];

export const tailwinds = [
  { title: "Broader allied demand", body: "Rising NATO and European commitments expand the long-term defense market, though they don't guarantee demand for specific programs." },
  { title: "Larger U.S. acquisition funding", body: "More funding for procurement, munitions, autonomy and industrial capacity creates a larger opportunity for Auto." },
  { title: "Growing need for affordable mass production", body: "Demand for high-volume, low-cost drones, munitions and autonomous systems plays to Auto's production strengths." },
  { title: "Technology and supplier overlap", body: "Shared technologies, components and suppliers narrow the gap between Auto's capabilities and defense needs." },
];

export const mitigants = [
  { title: "Government-sponsored entry", body: "DoW is engaging automakers directly, recruiting manufacturing expertise and connecting them with primes." },
  { title: "Faster acquisition pathways", body: "Expanded OTA, commercial-item and accelerated approaches reduce red tape for commercial entrants." },
  { title: "Greater order visibility", body: "DoW and Congress are pursuing larger, longer-term commitments for priority systems, though these remain program-specific." },
  { title: "Public funding of capacity", body: "Proposed funding for DPA purchases, industrial-base expansion, critical materials and financing reduces capital at risk." },
];

export const principles = [
  { title: "Play to Auto's strengths", body: "Industrialization, high-rate, cost-disciplined production, power, propulsion, EV, and thermal." },
  { title: "Focus on demand that rewards scale", body: "Repeatable, high-volume production over bespoke engineering." },
  { title: "Pursue returns that justify the commitment", body: "Weigh margin, growth, capital needs, and time to revenue together." },
  { title: "Favor accessible entry points", body: "Manageable qualification and access barriers, using partnerships to cut time and risk." },
  { title: "Target underserved supply chains", body: "Critical chains with limited supplier capacity, where auto scale adds resilience." },
];

export const pathways = [
  { n: 1, title: "Contract manufacturer", verdict: "Tactical step", body: "Build to defense players' designs with limited IP development and retention.",
    oem: "Assembly strengths enable rapid, lower-risk entry, but thin margins and limited IP make it a tactical step.",
    tier1: "High-rate parts production offers quick entry, but it's mainly a tactical step for larger, more integrated Tier 1s." },
  { n: 2, title: "Tier 1 to established defense players", verdict: "Strong fit", body: "Supply primes and scale-ups with self-developed IP and technology. Likely the best fit for OEMs and Tier 1s alike.", recommended: true,
    oem: "Likely best fit given margins, derisked entry and IP retention, despite the cultural shift to being a supplier; depends on finding willing defense partners.",
    tier1: "Builds on core strengths and current commercial models; IP supports margins while primes carry most program risk." },
  { n: 3, title: "Full defense OEM / Prime", verdict: "Risk likely too high", body: "Serve the DoW and other government entities directly.",
    oem: "OEMs would want this role, but the risk is likely too high competing head-to-head with defense primes.",
    tier1: "Platform ownership exceeds Tier 1 component strengths; high investment and program risk favor Option 2." },
];

export type Fit = "strong" | "moderate" | "poor";
export const valueChainFit: { stage: string; oem: Fit; tier1: Fit }[] = [
  { stage: "Design & engineering", oem: "moderate", tier1: "poor" },
  { stage: "Industrialization", oem: "strong", tier1: "strong" },
  { stage: "Component manufacturing", oem: "poor", tier1: "strong" },
  { stage: "Systems & subsystems", oem: "moderate", tier1: "strong" },
  { stage: "Final / platform assembly", oem: "strong", tier1: "moderate" },
  { stage: "Testing & qualification", oem: "poor", tier1: "poor" },
  { stage: "Aftermarket & sustainment", oem: "moderate", tier1: "poor" },
];

export const plays = [
  { id: "ground", title: "Ground vehicles", range: "$7–14B", low: 7, high: 14, pool: 17, fit: "OEMs and Tier 1s", body: "The full stack for OEMs: military trucks and utility vehicles build on commercial platforms. Tier 1s supply powertrain, EV, thermal, chassis and electrical systems." },
  { id: "drones", title: "Drones (UAVs)", range: "$10–32B", low: 10, high: 32, pool: 54, fit: "OEMs and Tier 1s", body: "Built to auto scale: OEMs bring line design and high-rate assembly; Tier 1s supply battery, motor, power electronics and sensors built outside China." },
  { id: "munitions", title: "Munitions", range: "$18–27B", low: 18, high: 27, pool: 53, fit: "Mainly Tier 1s", body: "The gap is production rate, not design. Tier 1s can ramp output of metal and electro-mechanical parts; brand exposure limits OEM fit." },
];

export const playTakeaways = [
  "$35–73B estimated annual addressable opportunity for Auto across the three priority plays, within a broader ~$125B FY27 funding pool",
  "Munitions offer an estimated $18–27B, versus $10–32B for drones and $7–14B for ground vehicles; drones have the widest range",
  "Auto's opportunity is the transferable portion, not the full platform value: estimates exclude defense-unique content",
];

export const successFactors = [
  { title: "Organize for speed", body: "Match a defense market moving to faster, iterative fielding." },
  { title: "Give primes a reason to partner", body: "Solve a real problem for them, not just offer capacity." },
  { title: "Bring the talent, not just the capacity", body: "Skilled labor, supplier depth and software matter as much as floor space." },
  { title: "Seek government-supported derisking", body: "Subsidized funding, pilots, and clearer demand before committing at scale." },
  { title: "Consider a dedicated defense unit", body: "Focused leadership and processes, separate from the core auto business." },
];

export const kpmgHelp = [
  { step: "Where to play", question: "Which defense plays best fit our capabilities, and how big is the prize?", body: "Opportunity screening across the defense value chain and platform systems; market sizing and OEM vs. Tier 1 fit assessment.", proof: "Dedicated A&D team of 25+ specialists across ground vehicles, UAS and munitions; 10+ years of automotive thought leadership." },
  { step: "How to enter", question: "Should we build, partner or buy our way into defense?", body: "Entry pathway evaluation; prime partner and target screening; commercial, financial and operational diligence.", proof: "Advisory to A&D corporations and leading PE sponsors; auto carve-outs and JVs (e.g., Clarios, $13.2B; JCI / Yanfeng, $8.5B revenue)." },
  { step: "Business case", question: "Will defense returns justify the investment and risk?", body: "Investment economics and business case development; revenue quality and margin analysis; government derisking options.", proof: "Proprietary frameworks linking revenue opportunities to cost and operating model requirements." },
  { step: "Defense readiness", question: "Can we meet the government's contracting and compliance requirements?", body: "Government contracting, compliance and cost accounting (CAS) readiness; dedicated defense unit design.", proof: "Advisory work for the U.S. Government and defense primes; government contracting and regulatory capabilities." },
  { step: "Scale-up", question: "How do we convert capacity and ramp production at defense quality?", body: "Plant conversion and site greenfielding; manufacturing footprint and operating model; post-deal integration.", proof: "Industry 4.0 / digital factory and operations strategy work (e.g., Tenneco / FM acquisition and integration, $5.4B)." },
];
