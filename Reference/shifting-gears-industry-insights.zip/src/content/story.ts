// All microsite copy lives here so it can be edited in one place.
// Figures sourced from "The Automotive Opportunity" (KPMG, Nov 2026).

export const nav = [
  { id: "now", label: "Now" },
  { id: "case", label: "Case study" },
  { id: "why", label: "Why not / Why now" },
  { id: "win", label: "Where to win" },
  { id: "kpmg", label: "KPMG" },
];

export const history = [
  { stat: "63 min", label: "Ford's Willow Run plant rolled out one B-24 bomber every 63 minutes using car assembly-line methods." },
  { stat: "#1", label: "By the end of WWII, GM was the largest US defense contractor, at ~$12B of war materiel." },
  { stat: "8 mo", label: "Chrysler built the Army's first dedicated tank plant and was turning out tanks within 8 months." },
];

export const realities = [
  { stat: "60–70%", label: "of casualties in Ukraine come from high-volume, first-person-view drones" },
  { stat: "$4M vs $20K", label: "A Patriot missile intercepting a Shahed-style drone: the cost curve has flipped" },
  { stat: "2–3×", label: "faster to production for disruptors than for traditional defense manufacturers" },
];

export const spending = [
  { value: 3, prefix: "~$", suffix: "T", label: "World military spending in 2025, the 10th straight annual increase" },
  { value: 14.6, prefix: "", suffix: "%", decimals: 1, label: "Average annual spending growth for NATO Europe & Canada over the past 3 years" },
  { value: 5, prefix: "~", suffix: "%", label: "of GDP: NATO's new defense spending commitment" },
  { value: 400, prefix: ">$", suffix: "B", label: "DoW FY27 procurement request, more than $200B above FY26" },
];

export const procurement = [
  { year: "FY26", value: 200, label: "<$200B" },
  { year: "FY27 request", value: 400, label: ">$400B" },
];

export const macrotrends = [
  {
    n: "01",
    title: "Competition from China",
    stat: "−6.6 pts",
    statLabel: "global share lost by the Detroit Three in 5 years",
    points: ["~5.6M units of capacity", "~35% cost advantage for a Chinese EV", "China is now the world's largest auto exporter"],
    implication: "Need for revenue diversification",
  },
  {
    n: "02",
    title: "Tech-integrated products",
    stat: "~50%",
    statLabel: "of vehicle cost will be electronics by 2030",
    points: ["Half of 2025 cars sold had L2 automation", "Auto software growing >4× faster than the auto market"],
    implication: "Capabilities that overlap with defense systems",
  },
  {
    n: "03",
    title: "Stranded capacity",
    stat: ">5M",
    statLabel: "vehicles of excess annual capacity in Europe",
    points: ["European plant utilization ~60%", "US utilization ~66% (Q2 2026)", "~100k European auto job cuts in 2024–25"],
    implication: "Capacity that could be repurposed for defense",
  },
];

export const caseStudy = {
  title: "Osnabrück: from car plant to air defense",
  context: [
    "VW carried >500k vehicles of surplus European capacity and planned to end Osnabrück production by summer 2027.",
    "In Sept. 2026, VW agreed to sell the site to Aurelius Capital (majority) and the State of Lower Saxony (minority).",
    "Rafael, maker of Iron Dome, joins as industrial partner. The Osnabrück workforce will industrialize air defense components, with VW contributing ramp-up expertise.",
  ],
  impact: [
    { stat: "75%", label: "of VW jobs expected to be retained" },
    { stat: "1st", label: "VW plant repurposed rather than closed" },
    { stat: "~45K", label: "at-risk employees at 4 other VW plants this model could reach" },
  ],
};

export const barriers = [
  {
    title: "Misaligned economics",
    problem: "Major programs take ~12 years to first capability, and volumes often miss auto return hurdles.",
    stat: "12 yrs",
    answer: "Larger US acquisition funding and longer-term commitments for priority systems improve order visibility.",
  },
  {
    title: "Volume uncertainty",
    problem: "Demand unwinds after conflicts (DoD procurement fell 52% in 1987–95), and 37 of the last 49 fiscal years started without a full budget.",
    stat: "−52%",
    answer: "Proposed public funding for capacity (DPA purchases, industrial-base expansion, financing) reduces the capital at risk.",
  },
  {
    title: "Cultural mismatch",
    problem: "Government-only contract terms, demands for technical data rights, and a second set of books for cost accounting.",
    stat: "2 sets",
    answer: "Faster OTA and commercial-item pathways, plus the DoW courting automakers directly and connecting them with primes.",
  },
];

export const principles = [
  { title: "Play to Auto's strengths", body: "Industrialization, high-rate, cost-disciplined production, power, propulsion, EV and thermal." },
  { title: "Focus on demand that rewards scale", body: "Repeatable, high-volume production over bespoke engineering." },
  { title: "Pursue returns that justify the commitment", body: "Weigh margin, growth, capital needs and time to revenue together." },
  { title: "Favor accessible entry points", body: "Manageable qualification and access barriers, using partnerships to cut time and risk." },
  { title: "Target underserved supply chains", body: "Critical chains with limited supplier capacity, where auto scale adds resilience." },
];

export const pathways = [
  { n: 1, title: "Contract manufacturer", verdict: "Tactical step", body: "Rapid, lower-risk entry, but thin margins and limited IP." },
  { n: 2, title: "Tier 1 to established defense players", verdict: "Best fit", body: "Captures margin on self-developed IP while primes carry program risk.", recommended: true },
  { n: 3, title: "Full defense OEM / Prime", verdict: "Risk likely too high", body: "Competes head-to-head with defense primes; high investment and program risk." },
];

export const plays = [
  {
    id: "ground",
    title: "Ground vehicles",
    range: "$7–14B",
    pool: 17,
    oem: "The full stack. Military trucks and utility vehicles build on commercial platforms, so OEMs keep the design IP and customer relationship, from line design to final assembly.",
    tier1: "The core product set. Military vehicles need what Tier 1s already sell: powertrain, EV, thermal, chassis and electrical systems, qualified and sold through primes.",
  },
  {
    id: "drones",
    title: "Drones (UAVs)",
    range: "$10–32B",
    pool: 54,
    oem: "Built to auto scale. DoW needs affordable, domestically built drones at volumes defense can't reach. OEMs bring line design, high-rate assembly and supply-base management; ISR and logistics limit brand risk.",
    tier1: "The subsystem supplier. Battery, motor, power electronics and sensor lines map directly, and suppliers built outside China are in demand.",
  },
  {
    id: "munitions",
    title: "Munitions",
    range: "$18–27B",
    pool: 53,
    oem: "Limited fit for OEMs given brand exposure. The opportunity sits mainly with suppliers.",
    tier1: "Capacity for hire. The gap is production rate, not design. Tier 1s can ramp output and supply metal and electro-mechanical parts.",
  },
];

export const successFactors = [
  { title: "Organize for speed", body: "Match a defense market moving to faster, iterative fielding." },
  { title: "Give primes a reason to partner", body: "Solve a real problem for them, not just offer capacity." },
  { title: "Bring the talent, not just the capacity", body: "Skilled labor, supplier depth and software matter as much as floor space." },
  { title: "Seek government-supported derisking", body: "Subsidized funding, pilots and clearer demand before committing at scale." },
  { title: "Consider a dedicated defense unit", body: "Focused leadership and processes, separate from the core auto business." },
];

export const kpmgHelp = [
  { step: "Where to play", body: "Prioritize platforms, value-chain roles and entry models against your capabilities." },
  { step: "Defense-entry readiness", body: "Government contracting, CAS compliance, partner and deal strategy to clear entry barriers." },
  { step: "Scale-up", body: "Operating model, capacity conversion and program execution to grow a defense business." },
];
