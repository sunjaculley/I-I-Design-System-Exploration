import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";
import {
  barriers, caseStudy, history, kpmgHelp, macrotrends, nav, pathways, plays, principles,
  procurement, realities, spending, successFactors,
} from "@/content/story";
import { CountUp, Reveal, SectionHeader, Sources, useInView } from "./primitives";

const wrap = "mx-auto w-full max-w-7xl px-6 md:px-10";

export function TopNav() {
  const [active, setActive] = useState("");
  const [progress, setProgress] = useState(0);
  useEffect(() => {
    const onScroll = () => {
      const h = document.documentElement;
      setProgress(h.scrollTop / Math.max(1, h.scrollHeight - h.clientHeight));
      let cur = "";
      for (const n of nav) {
        const el = document.getElementById(n.id);
        if (el && el.getBoundingClientRect().top < window.innerHeight * 0.4) cur = n.id;
      }
      setActive(cur);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-border bg-background/80 backdrop-blur">
      <div className={cn(wrap, "flex h-14 items-center justify-between")}>
        <a href="#top" className="font-display text-2xl tracking-tight">KPMG</a>
        <nav className="hidden gap-7 md:flex">
          {nav.map((n) => (
            <a key={n.id} href={`#${n.id}`} className={cn("text-xs uppercase tracking-[0.18em] transition-colors", active === n.id ? "text-primary" : "text-muted-foreground hover:text-foreground")}>
              {n.label}
            </a>
          ))}
        </nav>
        <a href="#kpmg" className="rounded-sm bg-secondary px-4 py-2 text-xs font-semibold uppercase tracking-wider text-secondary-foreground hover:bg-secondary/85">Talk to us</a>
      </div>
      <div className="h-0.5 bg-primary transition-[width]" style={{ width: `${progress * 100}%` }} />
    </header>
  );
}

export function Hero() {
  return (
    <section id="top" className="relative overflow-hidden bg-hero pt-14">
      <div className="absolute inset-0 grid-lines opacity-60" aria-hidden />
      <div className={cn(wrap, "relative flex min-h-[92vh] flex-col justify-center py-24")}>
        <Reveal><span className="eyebrow">A KPMG point of view · November 2026</span></Reveal>
        <Reveal delay={100}>
          <h1 className="mt-6 max-w-5xl text-5xl md:text-8xl">The Automotive Opportunity</h1>
        </Reveal>
        <Reveal delay={200}>
          <p className="mt-8 max-w-2xl text-xl text-muted-foreground md:text-2xl">
            How Auto's capabilities can strengthen the defense industrial base, and where automakers can play to win.
          </p>
        </Reveal>
        <Reveal delay={350}>
          <a href="#before" className="mt-12 inline-flex w-fit items-center gap-3 border-b border-primary pb-1 text-sm uppercase tracking-[0.2em] text-primary">
            Begin the story ↓
          </a>
        </Reveal>
      </div>
    </section>
  );
}

export function Before() {
  return (
    <section id="before" className="border-b border-border py-28">
      <div className={wrap}>
        <SectionHeader eyebrow="Prologue" title={<>Detroit has done this before.</>} intro="During WWII, America's automakers became its arsenal, building products they had never made before at speeds defense had never seen." />
        <div className="mt-16 grid gap-px overflow-hidden rounded-sm bg-border md:grid-cols-3">
          {history.map((h, i) => (
            <Reveal key={h.stat} delay={i * 120} className="bg-background p-8">
              <div className="font-display text-6xl text-primary md:text-7xl">{h.stat}</div>
              <p className="mt-4 text-muted-foreground">{h.label}</p>
            </Reveal>
          ))}
        </div>
        <Reveal className="mt-20 grid items-end gap-10 md:grid-cols-[1fr_1.2fr]">
          <div>
            <span className="eyebrow">Today</span>
            <div className="mt-4 font-display text-7xl md:text-9xl">0.4%</div>
            <p className="mt-3 max-w-sm text-muted-foreground">GM Defense's ~$700M share of group revenue. Auto's defense activity today is small and stays close to its core business.</p>
          </div>
          <blockquote className="border-l-2 border-primary pl-8 font-display text-3xl leading-tight md:text-5xl">
            Now, Washington is asking for Detroit <span className="text-primary">by name.</span>
          </blockquote>
        </Reveal>
        <Sources>GM, Ford, Chrysler historical records; company filings.</Sources>
      </div>
    </section>
  );
}

function ProcurementChart() {
  const { ref, inView } = useInView<HTMLDivElement>(0.4);
  const max = 400;
  return (
    <div ref={ref} className="flex h-64 items-end gap-6">
      {procurement.map((p) => (
        <div key={p.year} className="flex flex-1 flex-col items-center gap-3">
          <span className="font-display text-2xl">{p.label}</span>
          <div className="w-full rounded-t-sm bg-gradient-to-t from-secondary to-primary transition-[height] duration-[1400ms] ease-out" style={{ height: inView ? `${(p.value / max) * 180}px` : "0px" }} />
          <span className="text-xs uppercase tracking-widest text-muted-foreground">{p.year}</span>
        </div>
      ))}
    </div>
  );
}

export function ActNow() {
  return (
    <section id="now" className="py-28">
      <div className={wrap}>
        <SectionHeader act="Act I" eyebrow="What's happening now" title={<>Defense is shifting to <span className="text-primary">mass</span>. Traditional suppliers aren't built for it.</>} intro="Modern conflict rewards large-volume, cost-efficient production. The traditional defense industrial base runs low-rate, high-complexity production with a few specialized suppliers and multi-year qualification cycles." />
        <div className="mt-16 grid gap-6 md:grid-cols-3">
          {realities.map((r, i) => (
            <Reveal key={r.stat} delay={i * 120} className="rounded-sm border border-border bg-card p-8">
              <div className="font-display text-4xl text-primary md:text-5xl">{r.stat}</div>
              <p className="mt-4 text-muted-foreground">{r.label}</p>
            </Reveal>
          ))}
        </div>

        <div className="mt-28 grid gap-16 lg:grid-cols-[1.3fr_1fr]">
          <div>
            <Reveal><span className="eyebrow">The money is moving</span><h3 className="mt-4 text-3xl md:text-5xl">Spending is rising, and fast.</h3></Reveal>
            <div className="mt-10 grid grid-cols-2 gap-x-8 gap-y-12">
              {spending.map((s) => (
                <Reveal key={s.label}>
                  <div className="font-display text-5xl md:text-6xl"><CountUp value={s.value} prefix={s.prefix} suffix={s.suffix} decimals={s.decimals ?? 0} /></div>
                  <p className="mt-3 text-sm text-muted-foreground">{s.label}</p>
                </Reveal>
              ))}
            </div>
          </div>
          <Reveal className="rounded-sm border border-border bg-card p-8">
            <span className="eyebrow">DoW procurement</span>
            <p className="mt-2 text-sm text-muted-foreground">The FY27 request more than doubles procurement.</p>
            <div className="mt-8"><ProcurementChart /></div>
          </Reveal>
        </div>

        <div className="mt-28">
          <Reveal><span className="eyebrow">Meanwhile, in Auto</span><h3 className="mt-4 max-w-3xl text-3xl md:text-5xl">Three macrotrends are pushing Auto to evolve.</h3></Reveal>
          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {macrotrends.map((m, i) => (
              <Reveal key={m.n} delay={i * 120} className="flex flex-col rounded-sm border border-border bg-card p-8">
                <span className="font-display text-sm text-primary">{m.n}</span>
                <h4 className="mt-2 text-2xl">{m.title}</h4>
                <div className="mt-6 font-display text-5xl">{m.stat}</div>
                <p className="mt-2 text-sm text-muted-foreground">{m.statLabel}</p>
                <ul className="mt-6 space-y-2 text-sm text-muted-foreground">
                  {m.points.map((p) => <li key={p} className="border-t border-border pt-2">{p}</li>)}
                </ul>
                <p className="mt-auto pt-8 text-sm font-semibold text-primary">→ {m.implication}</p>
              </Reveal>
            ))}
          </div>
        </div>

        <Reveal className="mt-24 rounded-sm bg-secondary p-10 text-secondary-foreground md:p-16">
          <span className="text-xs font-semibold uppercase tracking-[0.22em] opacity-80">What it means</span>
          <p className="mt-5 max-w-4xl font-display text-3xl leading-tight md:text-5xl">
            Defense needs scale it can't build fast enough. Auto has scale it isn't fully using. The two curves are converging.
          </p>
        </Reveal>
        <Sources>SIPRI; NATO; DoW Comptroller FY24–FY27 budget documents; Reuters; Defense Daily; KPMG Research & Analysis.</Sources>
      </div>
    </section>
  );
}

export function CaseStudy() {
  return (
    <section id="case" className="bg-paper py-28 text-ink">
      <div className={wrap}>
        <Reveal>
          <span className="text-xs font-semibold uppercase tracking-[0.22em] text-cobalt">Case study</span>
          <h2 className="mt-5 max-w-4xl text-4xl md:text-6xl">{caseStudy.title}</h2>
        </Reveal>
        <div className="mt-14 grid gap-14 lg:grid-cols-[1.2fr_1fr]">
          <div className="space-y-6">
            {caseStudy.context.map((c, i) => (
              <Reveal key={i} delay={i * 100} className="flex gap-6 border-t border-ink/15 pt-6">
                <span className="font-display text-cobalt">0{i + 1}</span>
                <p className="text-lg">{c}</p>
              </Reveal>
            ))}
          </div>
          <div className="grid gap-px overflow-hidden rounded-sm bg-ink/15">
            {caseStudy.impact.map((m) => (
              <Reveal key={m.stat} className="bg-paper p-8">
                <div className="font-display text-6xl text-kpmg">{m.stat}</div>
                <p className="mt-2 text-ink/70">{m.label}</p>
              </Reveal>
            ))}
          </div>
        </div>
        <p className="mt-14 text-xs text-ink/50">Impact figures are early or anticipated. Sources: public announcements; KPMG analysis.</p>
      </div>
    </section>
  );
}

export function ActWhy() {
  return (
    <section id="why" className="py-28">
      <div className={wrap}>
        <SectionHeader act="Act II" eyebrow="Why it hasn't happened yet, and why it can" title={<>Three barriers kept Auto out. <span className="text-primary">Each one is easing.</span></>} intro="Since WWII, defense economics, demand swings and culture made the business hard to justify. Market tailwinds and active barrier mitigation are now changing that." />
        <div className="mt-16 space-y-6">
          <div className="hidden grid-cols-[1fr_auto_1fr] gap-8 px-8 text-xs uppercase tracking-[0.2em] text-muted-foreground md:grid">
            <span>What held Auto back</span><span /><span>What's changing</span>
          </div>
          {barriers.map((b, i) => (
            <Reveal key={b.title} delay={i * 100} className="grid gap-6 rounded-sm border border-border bg-card p-8 md:grid-cols-[1fr_auto_1fr] md:items-center md:gap-8">
              <div>
                <div className="flex items-baseline gap-4">
                  <span className="font-display text-4xl text-muted-foreground">{b.stat}</span>
                  <h3 className="text-2xl">{b.title}</h3>
                </div>
                <p className="mt-3 text-muted-foreground">{b.problem}</p>
              </div>
              <span className="font-display text-3xl text-primary md:rotate-0">→</span>
              <p className="text-lg">{b.answer}</p>
            </Reveal>
          ))}
        </div>
        <Reveal className="mt-20 text-center">
          <p className="font-display text-4xl md:text-6xl">The window is <span className="text-primary">open.</span></p>
        </Reveal>
        <Sources>Congressional Research Service; DoW FY2027 Mandatory Funding Overview and Acquisition Transformation Strategy; NATO; expert interviews; KPMG analysis.</Sources>
      </div>
    </section>
  );
}

export function ActWin() {
  const [play, setPlay] = useState("drones");
  const [lens, setLens] = useState<"oem" | "tier1">("oem");
  const current = plays.find((p) => p.id === play)!;
  return (
    <section id="win" className="border-t border-border bg-hero py-28">
      <div className={wrap}>
        <SectionHeader act="Act III" eyebrow="Where to play and how to win" title={<>Five principles for where Auto should play.</>} />
        <div className="mt-14 grid gap-4 md:grid-cols-5">
          {principles.map((p, i) => (
            <Reveal key={p.title} delay={i * 80} className="rounded-sm border border-border bg-card/70 p-6">
              <span className="font-display text-4xl text-primary">{i + 1}</span>
              <h3 className="mt-4 text-lg leading-snug">{p.title}</h3>
              <p className="mt-3 text-sm text-muted-foreground">{p.body}</p>
            </Reveal>
          ))}
        </div>

        <div className="mt-28">
          <Reveal><span className="eyebrow">Three ways in</span><h3 className="mt-4 text-3xl md:text-5xl">Supplying established defense players is the strongest fit.</h3></Reveal>
          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {pathways.map((p) => (
              <Reveal key={p.n} className={cn("rounded-sm border p-8", p.recommended ? "border-primary bg-secondary text-secondary-foreground" : "border-border bg-card/70")}>
                <span className="text-xs uppercase tracking-[0.2em] opacity-75">Option {p.n}</span>
                <h4 className="mt-3 text-2xl">{p.title}</h4>
                <span className={cn("mt-4 inline-block rounded-sm px-2 py-1 text-xs font-semibold uppercase tracking-wider", p.recommended ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground")}>{p.verdict}</span>
                <p className={cn("mt-4", p.recommended ? "opacity-90" : "text-muted-foreground")}>{p.body}</p>
              </Reveal>
            ))}
          </div>
        </div>

        <div className="mt-28">
          <Reveal><span className="eyebrow">Three major plays</span><h3 className="mt-4 text-3xl md:text-5xl">The strongest fit is industrializing systems and subsystems.</h3></Reveal>
          <div className="mt-10 flex flex-wrap items-center justify-between gap-4">
            <div className="flex flex-wrap gap-2">
              {plays.map((p) => (
                <button key={p.id} onClick={() => setPlay(p.id)} className={cn("rounded-sm border px-5 py-3 font-display text-lg transition-colors", play === p.id ? "border-primary bg-primary text-primary-foreground" : "border-border text-muted-foreground hover:text-foreground")}>
                  {p.title}
                </button>
              ))}
            </div>
            <div className="flex rounded-sm border border-border p-1" role="tablist">
              {(["oem", "tier1"] as const).map((l) => (
                <button key={l} onClick={() => setLens(l)} className={cn("rounded-sm px-4 py-2 text-xs font-semibold uppercase tracking-wider", lens === l ? "bg-secondary text-secondary-foreground" : "text-muted-foreground")}>
                  {l === "oem" ? "For OEMs" : "For Tier 1s"}
                </button>
              ))}
            </div>
          </div>
          <div className="mt-6 grid gap-6 rounded-sm border border-border bg-card p-8 md:grid-cols-[1fr_2fr] md:p-12">
            <div>
              <span className="eyebrow">Addressable for Auto</span>
              <div className="mt-3 font-display text-6xl">{current.range}</div>
              <p className="mt-2 text-sm text-muted-foreground">per year, of ~${current.pool}B value at stake (FY27)</p>
            </div>
            <p key={play + lens} className="animate-in fade-in text-xl leading-relaxed">{lens === "oem" ? current.oem : current.tier1}</p>
          </div>
        </div>

        <Reveal className="mt-28 grid items-center gap-12 md:grid-cols-2">
          <div>
            <span className="eyebrow">The size of the prize</span>
            <div className="mt-4 font-display text-7xl text-primary md:text-9xl">$35–73B</div>
            <p className="mt-4 max-w-md text-lg text-muted-foreground">Estimated annual opportunity for Auto across the three plays, within a broader <span className="text-foreground">~$125B</span> FY27 value pool.</p>
          </div>
          <div className="space-y-5">
            {plays.map((p) => (
              <div key={p.id}>
                <div className="flex justify-between text-sm"><span>{p.title}</span><span className="text-muted-foreground">{p.range} of ~${p.pool}B</span></div>
                <div className="mt-2 h-3 rounded-sm bg-muted"><div className="h-3 rounded-sm bg-gradient-to-r from-secondary to-primary" style={{ width: `${(p.pool / 54) * 100}%` }} /></div>
              </div>
            ))}
          </div>
        </Reveal>

        <div className="mt-28">
          <Reveal><span className="eyebrow">How to win</span><h3 className="mt-4 text-3xl md:text-5xl">Five key success factors.</h3></Reveal>
          <div className="mt-12 divide-y divide-border border-y border-border">
            {successFactors.map((s, i) => (
              <Reveal key={s.title} className="grid gap-2 py-6 md:grid-cols-[80px_1fr_1.4fr] md:items-baseline">
                <span className="font-display text-primary">0{i + 1}</span>
                <h4 className="text-2xl">{s.title}</h4>
                <p className="text-muted-foreground">{s.body}</p>
              </Reveal>
            ))}
          </div>
        </div>
        <Sources>FY27 DoW Budget Request; expert interviews (auto and A&D); KPMG analysis.</Sources>
      </div>
    </section>
  );
}

export function KpmgClose() {
  return (
    <section id="kpmg" className="bg-paper py-28 text-ink">
      <div className={wrap}>
        <Reveal>
          <span className="text-xs font-semibold uppercase tracking-[0.22em] text-cobalt">How KPMG can help</span>
          <h2 className="mt-5 max-w-4xl text-4xl md:text-6xl">Deep A&amp;D and Automotive expertise, under one roof.</h2>
          <p className="mt-6 max-w-2xl text-lg text-ink/70">A dedicated A&amp;D team of 25+ specialists across ground vehicles, UAS and munitions, plus more than a decade of automotive thought leadership and landmark auto deals.</p>
        </Reveal>
        <div className="mt-14 grid gap-6 md:grid-cols-3">
          {kpmgHelp.map((k, i) => (
            <Reveal key={k.step} delay={i * 100} className="rounded-sm border-t-4 border-kpmg bg-background/0 p-2 pt-6">
              <span className="font-display text-cobalt">Stage {i + 1}</span>
              <h3 className="mt-2 text-3xl">{k.step}</h3>
              <p className="mt-3 text-ink/70">{k.body}</p>
            </Reveal>
          ))}
        </div>
        <Reveal className="mt-24 flex flex-col items-start justify-between gap-8 rounded-sm bg-kpmg p-10 text-paper md:flex-row md:items-center md:p-14">
          <div>
            <h3 className="text-3xl md:text-5xl">Start the conversation.</h3>
            <p className="mt-3 opacity-80">Your Name, Title · name@kpmg.com · +1 (000) 000-0000</p>
          </div>
          <a href="mailto:name@kpmg.com" className="rounded-sm bg-sky px-6 py-4 text-sm font-semibold uppercase tracking-wider text-navy-deep hover:opacity-90">Get in touch</a>
        </Reveal>
      </div>
      <footer className={cn(wrap, "mt-20 text-xs text-ink/50")}>
        © 2026 KPMG LLP, a Delaware limited liability partnership, and its subsidiaries are part of the KPMG global organization of independent member firms affiliated with KPMG International Limited. All rights reserved.
      </footer>
    </section>
  );
}
