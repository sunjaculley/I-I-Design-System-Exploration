# Export the microsite as a full PDF

## What you'll get
A downloadable PDF of the whole microsite, from the opening WWII story to the KPMG close. It keeps the same order, KPMG Bold headlines, colours and charts, and gets saved to your Files.

## Approach
- Capture the live microsite page by page in landscape. That way each section sits on its own slide-like page and nothing gets cut off between pages.
- Show all animated content fully, with every number at its final value and every section visible.
- Print both the OEM and Tier 1 views for each play (ground vehicles, drones, munitions), because a PDF can't switch between them.
- Hide the top navigation bar. Add page numbers in the footer.
- The microsite itself stays exactly as it is.

## Quality check
Before you get it, I'll turn every page into an image and check it for clipped text, blank pages, missing fonts or awkward page breaks, and fix anything I find.

## Technical details
- Use a headless browser to print the page to PDF, with a temporary print stylesheet that only applies during the export. It forces `.reveal` content visible, expands the play toggles and sets page breaks per section.
- Output: `/mnt/documents/automotive-opportunity-kpmg.pdf`.
- Note: the placeholder contact details will still appear until the real ones are supplied.
