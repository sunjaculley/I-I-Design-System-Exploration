# Copy edits, chart alignment, and a lighter "Why not / Why now" section

## Top of the site
- Tighten the line spacing in "Auto's next industrial opportunity."
- The apostrophe in "Auto's" is correct: it's possessive (the opportunity belongs to Auto). It's an apostrophe, not a comma. I'll switch it to a curly apostrophe (’) so it looks right in KPMG Bold.

## Act I
- Headline: "Traditional" moves to the start of a new line on wider screens.
- Department of War chart: every bar will sit on the same baseline. The cause: the "FY27 (requested)" label wraps to two lines and lifts that bar up. All year labels get the same fixed height.

## Prologue
- Remove the periods at the end of the three WWII stat captions and the "Today" caption.
- Today caption: "Defense share of revenue among select Auto players with disclosed figures. Current participation remains limited and largely concentrated in core automotive capabilities" (the period between the two sentences stays; only the end period goes).

## Act II: lighter "Why it hasn't happened yet, and why it can"
Proposal to make it easier to read:
- **Barrier cards:** show the big stat and title, plus one bolded lead phrase per point (e.g. "Long timelines", "ROI & volume thresholds"). The full sentence goes in smaller text below.
- **What's changing:** show the eight item titles as a short checklist. Each item's body goes in smaller text below it, and the two groups stack more compactly.
- More space between the left (barriers) and right (what's changing) columns, plus a thin "then → now" arrow between them so the before/after is clear at a glance.
- All copy stays; only how it's grouped and how prominent it is changes.

Copy fixes in this section:
- 12 yrs: "Major defense programs…" (capital M); second point: "Defense volumes can be too small…" (capital D).
- 2 sets: "Complex processes…" (capital C); third point becomes "Additional accounting requirements: Government Cost Accounting Standards (CAS) alongside GAAP".
- Tailwinds: "Larger US acquisition funding" (no periods).
- Public funding of capacity: "…industrial-base expansion, critical materials, and financing…".
- Faster acquisition pathways: "Expanded OTA, commercial-item, and accelerated approaches…".
- Larger US acquisition funding: "procurement, munitions, autonomy, and industrial capacity".
- Growing need for affordable mass production: "high-volume, low-cost drones, munitions, and autonomous systems".
- Technology and supplier overlap: "Shared technologies, components, and suppliers…".

## Act III
- Three ways in headline: "Where should Auto play in the defense ecosystem?"
- Option 3 badge: "Risk likely too high" becomes "Higher risk".
- Option 3, For OEMs: "OEMs may consider this role, but…"
- Three major plays headline: "Industrializing systems and subsystems plays to Auto’s strengths"
- Ground vehicles: "Military trucks…" (capital M), "chassis, and electrical systems".
- Drones: "power electronics, and sensors".

## KPMG close
- Subheading: "Here's how we can help"
- Proof points line up along the bottom across all five stages.
- Stage 2: "commercial, financial, and operational diligence".
- Stage 4 proof points: "Advisory work for the US Government…" (no periods in US).
- Stage 4 body: "Government contracting, compliance, and cost accounting (CAS) readiness…".

## After the edits
- Check every changed section on screen at laptop and phone widths, then offer an updated PDF (v5).

## Technical details
- Copy changes in src/content/story.ts. Hero h1 gets `leading-[0.92]`; Act I title gets `<br className="hidden md:block" />` before "Traditional".
- ProcurementChart: year label gets `h-8` and starts at the top, so every bar's bottom edge lines up.
- KPMG stages: proof `<p>` gets `mt-auto` (the Reveal is already flex-col).
- Barrier points are split at the first ":" to make the bold lead phrase.
