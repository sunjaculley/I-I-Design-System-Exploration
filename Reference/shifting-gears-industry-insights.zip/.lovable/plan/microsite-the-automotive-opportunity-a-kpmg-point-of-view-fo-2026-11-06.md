# Microsite: "The Automotive Opportunity" — a KPMG point of view for an auto OEM

## The storyline (41 pages distilled to 3 acts + close)

The thread we tell: **Defense now needs what Auto does best: scale. Auto has done this before. The barriers that stopped it are starting to come down. Here is where to play and how to win.**

The "Why it hasn't happened yet" material does two jobs. The WWII history opens the story as the hook ("you've done this before"). The barriers and how they're easing set up Act 3 as the "why it can happen now" turn.

### Opening: "Detroit has done this before"
- Full-screen title: *The Automotive Opportunity*
- WWII stats: Willow Run built **one B-24 every 63 minutes**, GM was the **largest US defense contractor**, and Chrysler was **turning out tanks within 8 months**
- The contrast today: GM Defense is **~$700M, about 0.4% of revenue**
- Bridge line: "Washington is asking for Detroit by name."

### Act 1: What's happening now (the research)
- **Defense has changed.** Battlefields now run on cheap mass: **60–70% of Ukraine casualties** come from FPV drones, and **$4M Patriots** are shooting down **$20K drones**. Traditional suppliers build low-rate, complex systems on multi-year cycles.
- **Spending is surging** (animated counters): **~$3T** global military spend, the 10th straight annual rise. NATO is committing to **~5% of GDP**. The **FY27 procurement request is over $400B**, more than $200B above FY26.
- **Auto is under pressure:** three trends shown as cards
  1. Competition from China: **–6.6 pts** of global share, and a **35% cost gap**
  2. Tech-integrated vehicles: electronics will be **~50% of vehicle cost by 2030**
  3. Stranded capacity: Europe has **>5M units** of excess capacity, and US plants run at **66% utilization**
- **What it means:** an insight panel that ties both sides together. Defense needs scale, and Auto has scale it isn't using.

### Case study: Osnabrück
- VW's plant will move to Aurelius Capital and Lower Saxony, with Rafael as the industrial partner.
- Impact stats: **75% of jobs retained**, the **first** VW plant repurposed rather than closed, and **~45K** more at-risk workers this model could reach.

### Act 2: Why it hasn't happened, and why it can
- A two-column "Barrier → Mitigant" layout:
  - Misaligned economics (**12-year** programs) → bigger, longer-term funding and order visibility
  - Volume uncertainty (procurement fell **52%** in 1987–95; **37 of 49** years started without a full budget) → public funding of capacity and multi-year commitments
  - Cultural mismatch (data rights, government-only terms, a second set of books) → faster acquisition paths, and the department reaching out to automakers directly
- Closing message: the window is open.

### Act 3: Where to play and how to win
- **5 guiding principles** shown as numbered tiles
- **3 ways in**, compared: contract manufacturer, Tier 1 to the primes (**recommended**), or full defense prime
- **3 plays**, as interactive tabs with separate OEM and Tier 1 views: ground vehicles, drones, munitions
- The size of the prize: **$35–73B a year** you could compete for, within a **~$125B** total pool
- **5 key success factors**, as a short checklist

### Close: How KPMG can help
- A combined A&D and Auto team (25+ A&D specialists, a decade of auto thought leadership)
- Support at every stage: where to play → defense-entry readiness → scale-up
- A call to action: "Start the conversation", with a contact block. The contact details are placeholders until you send me the real ones.

## Design direction
- An editorial, magazine-style long scroll on a deep navy background with a bright KPMG-style blue accent. Stats are set in large, confident numbers.
- Headlines and big stat numbers use **KPMG Bold**, from the font file you uploaded. Body text uses a clean sans (Open Sans, or KPMG's body font if you send it).
- Colors follow the KPMG palette: KPMG blue (#00338D), cobalt (#1E49E2), light blue (#00B8F5) and deep navy.
- A sticky progress bar shows the acts (Now / Why Not / Why Now / Where to Win / KPMG), and stats animate in as you scroll.
- Charts are simple and custom-drawn (spend growth, the procurement jump).
- No stock photography. The visuals are bold typography, data, and abstract line art.

## Technical details
- KPMG-Bold.ttf is hosted as a project asset and loaded with @font-face as the display font.
- One long story page at `/` with in-page anchor navigation, since it's meant to be read as one story. It has a proper title and description for sharing.
- The content lives in a single data file so the copy is easy to edit. The sections are separate components.
- Animations use the IntersectionObserver API, with no heavy libraries. The page works well on mobile.
- The sources from the deck appear as footnotes under each section.
