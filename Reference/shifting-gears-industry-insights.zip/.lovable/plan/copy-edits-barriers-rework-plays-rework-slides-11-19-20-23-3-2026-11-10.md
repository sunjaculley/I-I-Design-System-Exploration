# Copy edits, barriers rework, plays rework (slides 11, 19–20, 23–30)

## Act I
- Headline: "Defense is shifting to **mass production**. Traditional suppliers aren't built for it." (highlight stays on "mass production")
- "The money is moving" headline: "Defense spending is rising, and fast."
- Chart label "DoW procurement" becomes "Department of War procurement"
- ~$3T caption: "Estimated world military spending in 2025, the 11th straight annual increase"
- Procurement chart rebuilt to slide 11's exact numbers: FY24 170, FY25 168, FY26 205 (153 base + 52 mandatory, +23%), FY27 requested 413 (**258** base + 156 mandatory, +101%). Each segment and each total gets its own label, like the slide. The FY27 label reads "FY27 (requested)". The footnote also notes that emergency supplementals (~$29B FY24, $6B FY25) aren't included. The site currently uses 257 for the FY27 base; this changes it to 258. Like the deck, the total still shows 413.
- What it means: "Defense needs scale it can't build fast enough. / Auto has scale it isn't fully using. / The opportunity lies where these two shifts meet." Each sentence gets its own line, with the tight line spacing kept.
- Sources line: "SIPRI; NATO; Department of War (DoW) Comptroller FY24–FY27 budget documents; Reuters; Defense Daily; KPMG Research & Analysis."

## Case study
- Title: "Osnabrück: From car plant to defense production"

## Act II: barriers (slides 19–20)
- Headline: "Three barriers held Auto back. Each one is easing." Your message had two periods after "back," so I'll use one.
- Subcopy: "Since WWII, defense economics, demand swings, and culture made the business hard to justify. Now market tailwinds and efforts to lower long-standing barriers are changing the equation."
- The rows that pair each barrier with one fix go away. The new layout has two sides:
  - **What held Auto back** (slide 19): three cards (misaligned economics, volume uncertainty, cultural mismatch), each with its stat (12 yrs, −52%, 2 sets of books) and the slide's points
  - **What's changing** (slide 20), in two groups:
    - **Market and fit tailwinds:** broader allied demand; larger U.S. acquisition funding; growing need for affordable mass production; technology and supplier overlap
    - **Active barrier mitigation:** government-sponsored entry; faster acquisition pathways; greater order visibility; public funding of capacity
- Sources come from slides 19–20.

## Act III
- Principle 1 body: "Industrialization, high-rate, cost-disciplined production, power, propulsion, EV, and thermal."
- Principle 3 body: "Weigh margin, growth, capital needs, and time to revenue together."
- Pathways (slide 23): option 2's badge changes from "Best fit" to "Strong fit." Each option card gets a short "For OEMs" note and a "For Tier 1s" note from slide 23, and a line saying option 2 is the strongest fit for both:
  - Option 1, OEMs: assembly strengths allow rapid, lower-risk entry, but thin margins and limited IP make it a tactical step. Tier 1s: high-rate parts production gives quick entry, but it's mainly tactical for larger, more integrated Tier 1s.
  - Option 2, OEMs: likely the best fit (margins, lower-risk entry, keeping IP), though working as a supplier takes a cultural adjustment and depends on finding willing partners. Tier 1s: builds on core strengths and current commercial models, with IP supporting margins while primes carry most of the program risk.
  - Option 3, OEMs: they would want this role, but the risk is likely too high going head-to-head with primes. Tier 1s: owning a platform goes beyond Tier 1 component strengths, and the high investment and risk favor option 2.
- Three major plays, reworked to follow slides 24–30:
  - New subheading: "Not every defense opportunity is a fit. The strongest build on existing capabilities and scale."
  - **Where Auto fits:** a fit chart across the value-chain stages (design and engineering through aftermarket), with an OEM row and a Tier 1 row rated strong, moderate or poor, from slides 25–26. It shows the full range of where each group fits rather than narrowing to one activity. OEMs fit best in industrialization and final assembly; Tier 1s fit best from industrialization through systems and subsystems production.
  - **Combined sizing (slide 30):** the OEM / Tier 1 toggle goes away and the three plays sit side by side, each shown once with a bar for value at stake and a bar for what Auto could address: Ground vehicles $17B / $7–14B, Drones $54B / $10–32B, Munitions $53B / $18–27B. The key-takeaway lines from slide 30 go underneath. One note per play says who it fits: ground vehicles and drones are OEM plays (the OEMs' two major plays), and munitions fit mainly Tier 1s. That removes the repeated numbers and the "$18–27B next to Limited fit for OEMs" clash.
  - "For Tier 1s" keeps a lowercase "s" everywhere, even inside all-caps labels.
- How to win, point 4: "Subsidized funding, pilots, and clearer demand before committing at scale."

## After the edits
- Check every changed section on screen at laptop and phone widths. Then offer an updated PDF (v4).

## Technical details
- Copy and data go in src/content/story.ts: new `tailwinds` / `mitigants` arrays, barrier `points`, pathway `oem`/`tier1` notes, `valueChainFit` matrix, and `plays` with `stake`/`range`/`fit` fields. The `oem`/`tier1` blurbs are removed.
- In Sections.tsx, ActWhy gets a two-column (barriers | changing) layout, ActWin swaps the lens tabs for a fit matrix plus a combined paired-bar chart, and labels with "Tier 1s" get a `normal-case` span so the uppercase eyebrow style doesn't turn it into "1S".
- ProcurementChart labels both segments and the total per bar.
