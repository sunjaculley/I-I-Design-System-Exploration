# Copy edits + procurement split

## Prologue, "Today"
- Big stat changes from 0.4% to **<1%–9%**
- Caption: "Defense share of revenue among select Auto players with disclosed figures. Current participation remains limited, with activity largely concentrated in companies' core automotive capabilities."
- Sources line: "Automotive News; The Henry Ford; U.S. Army; Archives of Michigan; U.S. Auto Industry in World War Two"

## Act I
- "Defense is shifting to mass" intro becomes: "Modern conflict rewards large-volume, cost-efficient production. The traditional defense industrial base runs on low-rate, high-complexity production, specialized suppliers, lengthy qualification cycles, and program-by-program execution."
- Spending stat: 14.6% shows as **~14.6%**
- Macrotrend 02 point: "Auto software expected to grow >4× faster than the auto market through 2035"

## Discretionary vs. mandatory (the >$400B stat)
The cleanest fix is to rebuild the procurement chart from slide 11 as a stacked bar chart:
- FY24 $170B, FY25 $168B (base only)
- FY26 $205B = $153B base + $52B mandatory
- FY27 request $413B = $258B base + $156B mandatory
- A two-colour legend ("Base (discretionary)" / "Mandatory / reconciliation"), plus growth tags (+23%, +101%)
- A short footnote: "Mandatory (reconciliation) funding comes from a fast-track budget law outside annual appropriations, first passed in 2025 (P.L. 119-21). Excludes emergency supplementals."
- The >$400B stat caption gets a light addition: "...more than $200B above FY26, incl. ~$156B mandatory funding"

## Osnabrück case study
- Point 2: "...the State of Lower Saxony (minority, and VW's #2 shareholder)."
- Point 3: "Rafael, maker of Iron Dome, plans to join as an industrial partner. The Osnabrück workforce will industrialize air defense components, with VW expected to contribute ramp-up expertise. (No missiles built on site.)"
- "1st" caption: "VW plant to be repurposed rather than closed"
- "~45K" caption: "at-risk employees at 4 other VW plants for whom this model could be considered"

## After the edits
- Re-export the PDF as a new version (automotive-opportunity-kpmg_v2.pdf) so the leave-behind matches the site, and check every page.

## Technical details
- Copy edits go in src/content/story.ts; the hardcoded prologue stat, caption, sources and Act I intro move from Sections.tsx into story.ts.
- `procurement` data becomes year rows with `base` / `mandatory` values; ProcurementChart renders stacked bars with semantic colour tokens.
