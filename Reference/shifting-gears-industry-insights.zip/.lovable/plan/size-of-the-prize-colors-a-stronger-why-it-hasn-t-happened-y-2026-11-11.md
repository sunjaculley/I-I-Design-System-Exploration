# Size-of-the-prize colors + a stronger "Why it hasn't happened yet" section

## 1. Size of the prize bar charts
The dark "Value at stake" bar is almost the same color as the card behind it.
- Change "Value at stake" to KPMG light blue (#00B8F5), so it stands out clearly on the navy.
- Keep "Addressable" in KPMG blue (#1E49E2), so the two bars look different from each other.
- Make the "Value at stake" number match its bar color so readers connect them.

## 2. Make "Why it hasn't happened yet, and why it can" hit harder
The section works now, but it reads like two lists of text. To give it more weight:
- **Lead with the numbers.** Each barrier card opens with a large stat (12 yrs, −52%, 2 sets) in KPMG Bold, with a one-line explanation under it ("average time for a major program to deliver first capability"). The headline numbers come first and the detail comes after.
- **Show what's easing.** Each barrier card gets a small "Easing" tag in light blue. This backs up the headline ("Each one is easing") without matching any barrier to one specific fix.
- **Clear before and after.** The "What held Auto back" side gets a dimmer, muted look and the "What's changing" side gets a brighter blue look, joined by a larger arrow, so the change from then to now shows at a glance.
- **Shorter "What's changing" items.** Show the titles with checkmarks first and the explanations in smaller, lighter text under them, so the list can be read in seconds.
- **Bigger close.** Give "The window is opening." more room above and below it and a thin light-blue line above it, so it lands as the section's final word.

All wording stays the same except the new one-line stat explanations, which come from the deck.

## Technical details
- `Sections.tsx`: in the plays card, change the pool bar from `bg-muted` to `bg-accent` and its label to `text-accent`; restyle the ActWhy layout as described above.
- `story.ts`: add a `statLabel` to each barrier.
- Then check on screen at 1280px and 390px.

## 3. "What it means" quote in the wide blue box
Each sentence gets its own line, which makes three lines:
```text
Defense needs scale it can't build fast enough.
Auto has scale it isn't fully using.
The opportunity lies where these two shifts meet.
```
- Let the quote use the full width of the box so each sentence fits on one line on laptop screens, with no single word dropping to the next line.
- On phones the text wraps on its own.
- If you meant two lines, tell me where you want the break.
- Technical: remove the max-width on the quote and keep the line break after each sentence (on desktop only).
