import lenny from "@/assets/team/lenny-larocca.jpg.asset.json";
import bala from "@/assets/team/bala-lakshman.jpg.asset.json";
import andrew from "@/assets/team/andrew-alesbury.jpg.asset.json";
// All microsite copy lives here so it can be edited in one place.
// Figures sourced from "The Automotive Opportunity" (KPMG, Nov 2026).

export const nav = [
  { id: "now", label: "Act I · Now" },
  { id: "case", label: "Case study" },
  { id: "why", label: "Act II · Barriers" },
  { id: "win", label: "Act III · Where to play" },
  { id: "kpmg", label: "KPMG" },
];

export const history = [
  { stat: "63 min", label: "Ford's Willow Run plant rolled out one B-24 bomber every 63 minutes using car assembly-line methods" },
  { stat: "#1", label: "By the end of WWII, GM was the largest US defense contractor, at ~$12B of war materiel" },
  { stat: "8 mo", label: "Chrysler built the Army's first dedicated tank plant and was turning out tanks within 8 months" },
];

export const prologueToday = {
  stat: "<1%–9%",
  label: "Defense share of revenue among select Auto players with disclosed figures. Current participation remains limited and largely concentrated in core automotive capabilities",
  sources: "Automotive News; The Henry Ford; U.S. Army; Archives of Michigan; U.S. Auto Industry in World War Two",
};

export const actNowIntro = "Modern conflict rewards large-volume, cost-efficient production. The traditional defense industrial base runs on low-rate, high-complexity production, specialized suppliers, lengthy qualification cycles, and program-by-program execution.";

export const realities = [
  { stat: "60–70%", label: "of casualties in Ukraine come from high-volume, first-person-view drones" },
  { stat: "$4M vs $20K", label: "A Patriot missile intercepting a Shahed-style drone: the cost curve has flipped" },
  { stat: "2–3×", label: "faster to production for disruptors than for traditional defense manufacturers" },
];

export const spending = [
  { value: 3, prefix: "~$", suffix: "T", label: "Estimated world military spending in 2025, the 11th straight annual increase" },
  { value: 14.6, prefix: "~", suffix: "%", decimals: 1, label: "Average annual spending growth for NATO Europe & Canada over the past 3 years" },
  { value: 5, prefix: "~", suffix: "%", label: "of GDP: NATO's new defense spending commitment" },
  { value: 400, prefix: ">$", suffix: "B", label: "DoW FY27 procurement request, more than $200B above FY26, incl. ~$156B mandatory funding" },
];

// DoW procurement budget requests ($B), slide 11
export const procurement: { year: string; base: number; mandatory: number; growth?: string; total?: number }[] = [
  { year: "FY24", base: 170, mandatory: 0 },
  { year: "FY25", base: 168, mandatory: 0 },
  { year: "FY26", base: 153, mandatory: 52, growth: "+23%" },
  { year: "FY27 (requested)", base: 258, mandatory: 156, growth: "+101%", total: 413 },
];

export const procurementNote = "Mandatory (reconciliation) funding comes from a fast-track budget law outside annual appropriations, first passed in 2025 (P.L. 119-21). Excludes emergency supplementals (~$29B in FY24 and $6B in FY25). FY27 segments as shown on the budget request; total $413B.";

export const macrotrends = [
  {
    n: "01",
    title: "Competition from China",
    stat: "−6.6 pts",
    statLabel: "global share lost by the Detroit Three in 5 years",
    points: ["~5.6M units of capacity", "~35% cost advantage for a Chinese EV", "China is now the world's largest auto exporter"],
    implication: "Need for revenue diversification",
  },
  {
    n: "02",
    title: "Tech-integrated products",
    stat: "~50%",
    statLabel: "of vehicle cost will be electronics by 2030",
    points: ["Half of 2025 cars sold had L2 automation", "Auto software expected to grow >4× faster than the auto market through 2035"],
    implication: "Capabilities that overlap with defense systems",
  },
  {
    n: "03",
    title: "Stranded capacity",
    stat: ">5M",
    statLabel: "vehicles of excess annual capacity in Europe",
    points: ["European plant utilization ~60%", "US utilization ~66% (Q2 2026)", "~100k European auto job cuts in 2024–25"],
    implication: "Capacity that could be repurposed for defense",
  },
];

export const caseStudy = {
  title: "Osnabrück: From car plant to defense production",
  context: [
    "VW carried >500k vehicles of surplus European capacity and planned to end Osnabrück production by summer 2027.",
    "In Sept. 2026, VW agreed to sell the site to Aurelius Capital (majority) and the State of Lower Saxony (minority, and VW's #2 shareholder).",
    "Rafael, maker of Iron Dome, plans to join as an industrial partner. The Osnabrück workforce will industrialize air defense components, with VW expected to contribute ramp-up expertise. (No missiles built on site.)",
  ],
  impact: [
    { stat: "75%", label: "of VW jobs expected to be retained" },
    { stat: "1st", label: "VW plant to be repurposed rather than closed" },
    { stat: "~45K", label: "at-risk employees at 4 other VW plants for whom this model could be considered" },
  ],
};

export const barriers = [
  { title: "Misaligned economic expectations", stat: "12 yrs", statLabel: "Average time for a major program to deliver first capability", points: ["Long timelines: Major defense programs take 12 years on average to deliver first capability, so capital takes far longer to pay back", "ROI & volume thresholds: Defense volumes can be too small and uncertain to clear auto return hurdles"] },
  { title: "Volume uncertainty", stat: "−52%", statLabel: "Drop in DoD procurement after the Cold War, 1987–95", points: ["Demand declines sharply after conflicts (DoD procurement fell 52% in 1987–95)", "Unpredictable budget timing: 37 of the last 49 fiscal years started without a full-year budget", "Programs can be cancelled midstream, stranding suppliers' investments"] },
  { title: "Cultural mismatch", stat: "2 sets", statLabel: "Of accounting books: CAS alongside GAAP", points: ["Government-specific buying: Complex processes, government-only terms and long contracting timelines", "IP ownership: DoW often seeks rights to contractors' technical data", "Additional accounting requirements: Government Cost Accounting Standards (CAS) alongside GAAP"] },
];

export const tailwinds = [
  { title: "Broader allied demand", body: "Rising NATO and European commitments expand the long-term defense market, though they don't guarantee demand for specific programs." },
  { title: "Larger US acquisition funding", body: "More funding for procurement, munitions, autonomy, and industrial capacity creates a larger opportunity for Auto." },
  { title: "Growing need for affordable mass production", body: "Demand for high-volume, low-cost drones, munitions, and autonomous systems plays to Auto's production strengths." },
  { title: "Technology and supplier overlap", body: "Shared technologies, components, and suppliers narrow the gap between Auto's capabilities and defense needs." },
];

export const mitigants = [
  { title: "Government-sponsored entry", body: "DoW is engaging automakers directly, recruiting manufacturing expertise and connecting them with primes." },
  { title: "Faster acquisition pathways", body: "Expanded OTA, commercial-item, and accelerated approaches reduce red tape for commercial entrants." },
  { title: "Greater order visibility", body: "DoW and Congress are pursuing larger, longer-term commitments for priority systems, though these remain program-specific." },
  { title: "Public funding of capacity", body: "Proposed funding for DPA purchases, industrial-base expansion, critical materials, and financing reduces capital at risk." },
];

export const principles = [
  { title: "Play to Auto's strengths", body: "Industrialization, high-rate, cost-disciplined production, power, propulsion, EV, and thermal." },
  { title: "Focus on demand that rewards scale", body: "Repeatable, high-volume production over bespoke engineering." },
  { title: "Pursue returns that justify the commitment", body: "Weigh margin, growth, capital needs, and time to revenue together." },
  { title: "Favor accessible entry points", body: "Manageable qualification and access barriers, using partnerships to cut time and risk." },
  { title: "Target underserved supply chains", body: "Critical chains with limited supplier capacity, where auto scale adds resilience." },
];

export const glance = {
  stats: [
    { stat: "~$3T", label: "Global military spending in 2025, the 11th straight annual increase" },
    { stat: ">$400B", label: "DoW FY27 procurement request, more than double FY26" },
    { stat: "$35–73B", label: "Estimated annual addressable opportunity for Auto across three priority plays" },
  ],
  line: "Defense needs production at scale. Auto has the scale, the capabilities, and the capacity to provide it.",
};

// Explanations drafted from standard defense-contracting practice; for KPMG review.
export const operatingDifferences: { title: string; tag?: string; body: string }[] = [
  { title: "Contract types and cost accounting", body: "Defense contracts follow government cost accounting standards (CAS), which means keeping a second set of books alongside GAAP." },
  { title: "Export controls on technical data", body: "The government often seeks rights to contractors' technical data, and export rules limit who can access it, including non-US staff and partners" },
  { title: "Use of offshore resources", body: "Offshore engineering and IT teams may not be able to work on defense programs" },
  { title: "Cybersecurity requirements", body: "Contractors and their suppliers must meet defense cybersecurity standards to handle sensitive government information, and must be certified before they can win a contract" },
  { title: "Defense sustainment and supply chains", body: "Aftermarket work is often controlled by prime-held contracts, data rights and depot rules." },
];

export const multiRegime = "Complexity multiplies when serving several governments at once: US, NATO allies and EU buyers each bring their own export, data, security and sourcing rules, and they can overlap or conflict.";

export const pathways = [
  { n: 1, title: "Contract manufacturer", body: "Build to defense players' designs with limited IP development and retention.",
    when: "Speed and low risk matter most, and there is available assembly or parts capacity to put to work",
    pros: ["Rapid, lower-risk entry", "Puts existing manufacturing capacity and processes to work"],
    cons: ["Thin margins make it largely a tactical step", "Limited IP development and retention"] },
  { n: 2, title: "Tier 1 to established defense players", body: "Supply primes and scale-ups with self-developed IP and technology.",
    when: "There is IP and technology to protect, and willing prime or scale-up partners",
    pros: ["Better margins and IP retention", "Derisked entry, with primes carrying most program risk", "Leverages existing subsystem and engineering strengths"],
    cons: ["Less control over overall program and end-customer relationship", "Depends on finding willing defense partners"] },
  { n: 3, title: "Full defense OEM / Prime", body: "Serve the DoW and other government entities directly.",
    when: "The goal is platform ownership, and the business can absorb high investment and program risk",
    pros: ["Full platform value and direct customer relationship"],
    cons: ["Competing head-to-head with established primes", "High investment, qualification, and program risk", "Requires full-platform integration and lifecycle support"] },
];

export type Fit = "strong" | "moderate" | "poor";
// Slides 25 (OEMs) and 26 (Tier 1s), wording from the deck.
export const valueChainFit: { stage: string; description: string; oem: Fit; oemNote: string; tier1: Fit; tier1Note: string }[] = [
  { stage: "Design & engineering", description: "Turning requirements into a buildable product: concept design, detailed engineering, prototyping and design for cost and manufacturability", oem: "moderate", oemNote: "OEM design skills transfer in some areas (e.g., ground vehicles), but specialized defense expertise, security and IP terms raise entry barriers and limit near-term returns", tier1: "poor", tier1Note: "Tier 1 product engineering fits familiar systems, but specialized defense expertise and IP terms complicate entry, with slow development revenue limiting standalone appeal" },
  { stage: "Industrialization", description: "Getting a design ready for repeatable production: process engineering, tooling, line setup, supplier qualification and the ramp to target production rate", oem: "strong", oemNote: "Core OEM strength in line setup and supplier management addresses defense capacity gaps, making this a best-fit entry point to scale production with existing expertise", tier1: "strong", tier1Note: "Tier 1 process engineering and ramp-up expertise address defense capacity gaps, making industrialization an attractive route to scale production with existing capabilities" },
  { stage: "Component manufacturing", description: "Making individual parts from raw or processed materials, such as machined, cast, formed and composite parts, electronic boards and wiring", oem: "poor", oemNote: "OEMs outsource much component production, limiting fit; however, build-to-print work offers simpler entry but modest margins and supplier qualification requirements", tier1: "strong", tier1Note: "Tier 1 high-rate parts production addresses defense shortages, offering a priority entry through prime supply chains with existing assets and limited new R&D" },
  { stage: "Systems & subsystems", description: "Combining components into functional systems for propulsion, power, thermal management, actuation or sensing on a defense platform", oem: "moderate", oemNote: "Powertrain and thermal skills offer selective opportunities (esp. ground vehicles), with IP supporting higher margins, but qualification and data controls raise entry barriers", tier1: "strong", tier1Note: "Tier 1 integration and proprietary technology match defense subsystem needs, offering a priority opportunity for higher margins and recurring revenue through primes" },
  { stage: "Final / platform assembly", description: "Putting structures and subsystems together into a complete, working end product", oem: "strong", oemNote: "Supplier management and final assembly directly match OEM capabilities, offering a best-fit route through prime designs that leverage existing skills and limit new R&D", tier1: "moderate", tier1Note: "Subsystem assembly skills transfer, but full-platform integration exceeds Tier 1s’ core focus, with prime access, security rules and thin margins limiting appeal" },
  { stage: "Testing & qualification", description: "Demonstrating that components, subsystems and platforms meet performance, safety, environmental and contract requirements before acceptance", oem: "poor", oemNote: "OEM validation skills transfer, but specialized defense test facilities and acceptance rules raise entry costs for a small standalone profit pool", tier1: "poor", tier1Note: "Tier 1 validation skills support product qualification, but specialized defense facilities and acceptance rules raise entry costs for a small standalone profit pool" },
  { stage: "Aftermarket & sustainment", description: "Keeping fielded platforms operational over their life through repair, overhaul, remanufacturing, and upgrades", oem: "moderate", oemNote: "OEM remanufacturing skills support lifecycle services, with attractive recurring margins, but prime contracts, data rights and depot rules restrict access", tier1: "poor", tier1Note: "Tier 1 remanufacturing skills support selected repairs, but prime-held contracts, data rights and depot rules restrict entry and access to attractive recurring service margins" },
];

export const plays = [
  { id: "ground", title: "Ground vehicles", range: "$7–14B", low: 7, high: 14, pool: 17, fit: "OEMs and Tier 1s", body: "The full stack for OEMs: Military trucks and utility vehicles build on commercial platforms. Tier 1s supply powertrain, EV, thermal, chassis, and electrical systems." },
  { id: "drones", title: "Drones (UAVs)", range: "$10–32B", low: 10, high: 32, pool: 54, fit: "OEMs and Tier 1s", body: "Built to auto scale: OEMs bring line design and high-rate assembly; Tier 1s supply battery, motor, power electronics, and sensors built outside China." },
  { id: "munitions", title: "Munitions", range: "$18–27B", low: 18, high: 27, pool: 53, fit: "Mainly Tier 1s", body: "The gap is production rate, not design. Tier 1s can ramp output of metal and electro-mechanical parts; brand exposure limits OEM fit." },
];

export const playTakeaways = [
  "$35–73B estimated annual addressable opportunity for Auto across the three priority plays, within a broader ~$125B FY27 funding pool",
  "Munitions offer an estimated $18–27B, versus $10–32B for drones and $7–14B for ground vehicles; drones have the widest range",
  "Auto's opportunity is the transferable portion, not the full platform value: estimates exclude defense-unique content",
];

export const successFactors: { title: string; body: string }[] = [
  { title: "Consider a dedicated defense unit", body: "Establish the business model and compliance perimeter first. Decide how defense work will sit relative to the core Auto business – integrated, firewalled, ring-fenced, or partnership/JV – before designing the operating model." },
  { title: "Organize for speed", body: "Defense buying is getting faster and more iterative, as new entrants field products quickly and improve them in service. Auto will need to keep pace." },
  { title: "Give primes a reason to partner", body: "Primes control access to most defense programs. Auto earns a place by solving a real problem, not simply offering more capacity." },
  { title: "Bring the talent, not just the capacity", body: "Defense production is constrained by more than factory space. Skilled labor, supplier depth, and software capability matter too, making Auto’s broader production system its real advantage." },
  { title: "Seek government-supported derisking", body: "Reduce the risk of entry by working with government. Funding, pilots, and clearer demand signals can support investment in specialized capabilities before scaling up." },
];

export const whatItMeans = {
  headline: "Defense can't build scale fast enough. Auto has scale to spare.|But capacity alone won't win.",
  body: "Defense runs on different contracts, compliance requirements and supply chains. Success requires navigating both worlds.",
};

export const actWhyIntro = "Auto brings a lot to the table, but entering Defense is not simply a matter of applying what already works. The challenges run much deeper.";

// Potential by value-chain stage, read from deck slides 28 (OEMs) and 29 (Tier 1s). h = high, m = moderate, l = limited.
export type Potential = "h" | "m" | "l";
export const oemStages = ["Industrialization", "Component manufacturing", "Systems & subsystems", "Final / platform assembly"];
export const tier1Stages = ["Industrialization", "Component manufacturing", "Systems & subsystems"];
export const platformSystems: { name: string; description: string; oem: Potential[]; tier1: Potential[] }[] = [
  { name: "Air platforms (crewed)", description: "Fixed-wing, rotary-wing and powered-lift aircraft, along with lighter-than-air systems", oem: ["l", "l", "l", "l"], tier1: ["l", "m", "l"] },
  { name: "Ground vehicles", description: "Combat vehicles, combat-support vehicles, logistics and utility vehicles, and unmanned ground vehicles and robots, in tactical and armored variants", oem: ["h", "h", "h", "h"], tier1: ["h", "h", "h"] },
  { name: "Naval platforms", description: "Aircraft carriers, other surface combatants, submarines, amphibious and support vessels, and uncrewed surface and underwater vessels", oem: ["l", "l", "l", "l"], tier1: ["l", "m", "l"] },
  { name: "Drones (UAVs)", description: "Small tactical drones, long-endurance drones, and collaborative combat aircraft, incl. attritable designs", oem: ["h", "m", "m", "h"], tier1: ["h", "h", "h"] },
  { name: "Space & launch systems", description: "Satellites, other spacecraft, launch vehicles, and supporting ground infrastructure", oem: ["m", "l", "l", "l"], tier1: ["m", "m", "l"] },
  { name: "Missiles & rockets", description: "Ballistic missiles, cruise missiles, other guided missiles, and unguided rockets", oem: ["h", "m", "l", "l"], tier1: ["m", "m", "m"] },
  { name: "Precision guided munitions", description: "Guided aerial ordnance, guided gun / mortar rounds, and loitering munitions", oem: ["h", "m", "l", "l"], tier1: ["h", "h", "m"] },
  { name: "Artillery & ammunition", description: "Gun-based artillery, mortar systems, and unguided ammunition, such as shells and cartridges", oem: ["h", "m", "l", "l"], tier1: ["h", "h", "l"] },
];

export const kpmgHelp = [
  { step: "Where to play", question: "Which defense plays best fit our capabilities, and how big is the prize?", body: "Opportunity screening across the defense value chain and platform systems; market sizing and OEM vs. Tier 1 fit assessment.", proof: "Dedicated A&D team of 25+ specialists across ground vehicles, UAS and munitions; 10+ years of automotive thought leadership." },
  { step: "How to enter", question: "Should we build, partner or buy our way into defense?", body: "Entry pathway evaluation; prime partner and target screening; commercial, financial, and operational diligence.", proof: "Advisory to A&D corporations and leading PE sponsors; auto carve-outs and JVs (e.g., Clarios, $13.2B; JCI / Yanfeng, $8.5B revenue)." },
  { step: "Business case", question: "Will defense returns justify the investment and risk?", body: "Investment economics and business case development; revenue quality and margin analysis; government derisking options.", proof: "Proprietary frameworks linking revenue opportunities to cost and operating model requirements." },
  { step: "Defense readiness", question: "Can we meet the government's contracting and compliance requirements?", body: "Government contracting, compliance, and cost accounting (CAS) readiness; dedicated defense unit design.", proof: "Advisory work for the US Government and defense primes; government contracting and regulatory capabilities." },
  { step: "Scale-up", question: "How do we convert capacity and ramp production at defense quality?", body: "Plant conversion and site greenfielding; manufacturing footprint and operating model; post-deal integration.", proof: "Industry 4.0 / digital factory and operations strategy work (e.g., Tenneco / FM acquisition and integration, $5.4B)." },
];

export const contacts = [
  { name: "Lenny LaRocca", initials: "LL", photo: lenny.url },
  { name: "Bala Lakshman", initials: "BL", photo: bala.url },
  { name: "Andrew Alesbury", initials: "AA", photo: andrew.url },
];
