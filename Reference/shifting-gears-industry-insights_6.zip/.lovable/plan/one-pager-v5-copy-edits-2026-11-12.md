# One-pager v5: copy edits

Builds on v4 (same layout and look). v4 stays unchanged; output is a new file, `autos-next-industrial-opportunity-one-pager_v5.pdf`.

## Changes
1. **Main headline:** remove the blue period after "Auto's next industrial opportunity".
2. **01 body copy:** "Defense now runs on mass: drones, munitions, and vehicles built fast, at scale, and at low cost." New paragraph: "Auto has the scale, the manufacturing discipline, and the tech capabilities to deliver."
3. **02 headline:** "But the roadblocks for Auto are steep"
4. **03 eyebrow:** "THE OPPORTUNITY"
5. **03 body copy:** last portion becomes "Up to $73B a year is in play."
6. **Keys to success:** "Keys to success: Set the right business model and compliance perimeter. Organize for speed. Offer industrial expertise, not just capacity."
7. **Bottom band:** remove the QR code; the link text fills the band cleanly.
8. **Bottom headline:** "To see your potential path into the defense sector, visit our microsite." followed by the link.
9. **Link:** https://kpmg-design.ceros.site/i-and-i-ford-shifting-gears (shown and clickable in the PDF).

## Technical details
- Rebuild the standalone HTML (recreate from v4 if the temp source was wiped), print to US Letter PDF via headless Chromium.
- QA: render page to image, check for overflow/overlap, especially the bottom band after QR removal.
- Add v5 to the "KPMG executive leave-behind PDFs" collection.
