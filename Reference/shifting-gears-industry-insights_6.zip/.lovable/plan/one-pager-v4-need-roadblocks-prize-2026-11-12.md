# One-pager v4: need → roadblocks → prize

Same simple v3 layout (navy, KPMG Bold, three numbered points, blue "Learn more" band with link and QR code). Only the story angle of the three points changes. Saved as a new file; v3 stays as is.

## Proposed points

```text
01  THE NEED
    Modern defense needs what Auto does best
    Defense now runs on mass: drones, munitions and vehicles built fast,
    at scale and at low cost. Auto has the scale, the manufacturing
    discipline and the tech capabilities to provide it.

02  THE CHALLENGE
    But it's not a slam dunk
    Defense is a fundamentally different business: long program
    timelines, volume uncertainty, and strict operating differences
    (contracts and cost accounting, export controls, cybersecurity
    and sustainment). The roadblocks for Auto are steep.

03  THE PRIZE
    Done right, the prize is huge
    These challenges can be overcome: funding is growing, acquisition
    is getting faster, and the department is reaching out to Auto.
    Up to $35-73B a year is in play:
    [Ground vehicles $7-14B] [Drones $10-32B] [Munitions $18-27B]
    Keys to success: set the business model and compliance perimeter
    first, partner with primes and government to lower entry risk.
```

## Notes
- All facts and figures come from your v3 content and the site; the new headlines are my wording, so please check them.
- The small labels ("The need", "The challenge", "The prize") replace "Why Auto? / Why now? / Where to play".
- With less text per point, the headlines can return to the larger v2 size.
- I'll check the page as an image for clipping and overlap before sending.

## Technical details
- Reuse the v3 HTML, edit copy only, print via headless Chromium to /mnt/documents/autos-next-industrial-opportunity-one-pager_v4.pdf and add it to the leave-behind collection.
