# Update "Three ways in" with the new copy

Only the wording of the three options changes. Layout, order and styling stay as they are.

## Changes, from your document

**Option 1: Contract manufacturer**
- Description and "When it makes sense": no change
- Pros: "Rapid, lower-risk entry" / "Puts existing manufacturing capacity and processes to work" (new)
- Cons: "Thin margins make it largely a tactical step" (new) / "Limited IP development and retention"

**Option 2: Tier 1 to established defense players**
- Description and "When it makes sense": no change
- Pros: "Better margins and IP retention" / "Derisked entry, with primes carrying most program risk" / "Leverages existing subsystem and engineering strengths" (new)
- Cons: "Less control over overall program and end-customer relationship" (new) / "Depends on finding willing defense partners" (adds "willing")

**Option 3: Full defense OEM / Prime**
- Description and "When it makes sense": no change
- Pros: "Full platform value and direct customer relationship"
- Cons: "Competing head-to-head with established primes" / "High investment, qualification, and program risk" (adds "qualification") / "Requires full-platform integration and lifecycle support" (new)

## Technical details
- Edit only the `pathways` entries in `src/content/story.ts`.
- Check the three cards in the preview so the extra line on Option 3 still lines up.
- The site PDF and one-pager stay as they are until you ask for a new export.
