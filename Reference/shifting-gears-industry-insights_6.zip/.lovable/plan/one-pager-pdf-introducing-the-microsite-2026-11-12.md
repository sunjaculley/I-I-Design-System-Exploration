# One-pager PDF introducing the microsite

## What you'll get
A single-page, US Letter portrait PDF matching the microsite: deep navy background, KPMG Bold headlines, KPMG blue / light blue accents, Open Sans body. Saved to Files and added to the leave-behind PDFs collection.

## Layout (top to bottom)
```text
[light blue eyebrow]  A KPMG POINT OF VIEW
[KPMG Bold headline]  Auto's next industrial opportunity
[subline]             The core facts
------------------------------------------------------------
01 Why Auto?          | 02 Why now?        (two columns, numbered like the site)
------------------------------------------------------------
03 Where to play and how to win
   Entry points (one line)
   Three stat tiles in KPMG Bold:
   Ground vehicles $7-14B | Drones (UAVs) $10-32B | Munitions $18-27B   (annually)
   Keys to success (one line)
------------------------------------------------------------
[KPMG blue band] 04 Learn more: The full microsite provides detailed data
                 and strategic analysis. + site link + QR code
```

## Copy
All wording comes from your document as written. The headline follows the site's sentence case ("Auto's next industrial opportunity").

## Notes
- The link and QR code point to the published site: shifting-gears-industry-insights.lovable.app. Tell me if you'll use a different address.
- I'll check the page as an image for clipping, spacing and font issues before I send it.

## Technical details
- Built as standalone HTML with the KPMG-Bold font, printed to PDF via headless Chromium. The microsite itself isn't changed.
- Output: /mnt/documents/autos-next-industrial-opportunity-one-pager.pdf
